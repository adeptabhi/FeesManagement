package Fees_Management_System;
import java.sql.Connection;
import java.sql.DriverManager;
public class DBConnection
{
        static Connection con = null;
        public static Connection getConnection()
        {
          try
          {
              Class.forName("com.mysql.cj.jdbc.Driver");
              con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fees_management","root","Abhi@4455");  
          }
          catch (Exception e)
          {
              e.printStackTrace();
          }
          return con;
        }  
}
