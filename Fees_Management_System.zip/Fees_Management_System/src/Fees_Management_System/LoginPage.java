package Fees_Management_System;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
public class LoginPage extends javax.swing.JFrame {
public LoginPage() {
        initComponents();
    }
    void userVerification(String userName,String password)
    {
        if(userName.length()<8||userName.substring(7).matches("^[0-9]*$")==false)
          JOptionPane.showMessageDialog(this,"invalid username or password");
        else
        {   
          int userId=Integer.parseInt(userName.substring(7));  
         try
            {
              Connection con=DBConnection.getConnection();
              String sql="select id, password from signupPage where id =? and password = ?";
              PreparedStatement pst= con.prepareStatement(sql);
              pst.setInt(1,userId);
              pst.setString(2,password);
              ResultSet rs=pst.executeQuery();
              if(rs.next()&&userName.substring(0,7).equals("UIETID-"))
                      {   
                           HomePage home=new HomePage();
                           home.show();
                           this.dispose(); 
                      }
              else
              {
                   txt_password.setText("");
                   txt_userName.setText("");
                   alertUserName.setText("Enter your username");
                   alertPassword.setText("Enter your password");
                  JOptionPane.showMessageDialog(this,"invalid username or password");
              }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            } 
        } 
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainLoginPanel = new javax.swing.JPanel();
        loginPage = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        loginPageLabel = new javax.swing.JLabel();
        loginAccountLabel = new javax.swing.JLabel();
        userNameLabel = new javax.swing.JLabel();
        passwordLabel = new javax.swing.JLabel();
        btn_login = new javax.swing.JButton();
        btn_exit = new javax.swing.JButton();
        btn_signup = new javax.swing.JButton();
        txt_userName = new javax.swing.JTextField();
        txt_password = new javax.swing.JPasswordField();
        alertPassword = new javax.swing.JTextField();
        alertUserName = new javax.swing.JTextField();
        separator3 = new javax.swing.JSeparator();
        loginImageLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("LoginPageFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainLoginPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainLoginPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainLoginPanel.setForeground(new java.awt.Color(51, 51, 51));
        mainLoginPanel.setPreferredSize(new java.awt.Dimension(1248, 648));
        mainLoginPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loginPage.setBackground(new java.awt.Color(0, 153, 153));
        loginPage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        loginPage.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(492, 0, 60, -1));

        loginPageLabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        loginPageLabel.setForeground(new java.awt.Color(255, 255, 255));
        loginPageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyIcons/admin.png"))); // NOI18N
        loginPageLabel.setText("User Login Page");
        loginPage.add(loginPageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 340, 70));

        loginAccountLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        loginAccountLabel.setForeground(new java.awt.Color(255, 255, 255));
        loginAccountLabel.setText("Login To Your Account");
        loginPage.add(loginAccountLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, -1, -1));

        userNameLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        userNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        userNameLabel.setText("UserName:");
        loginPage.add(userNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 110, 25));

        passwordLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        passwordLabel.setForeground(new java.awt.Color(255, 255, 255));
        passwordLabel.setText("Password:");
        loginPage.add(passwordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, 110, 25));

        btn_login.setBackground(new java.awt.Color(0, 102, 102));
        btn_login.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_login.setForeground(new java.awt.Color(255, 255, 255));
        btn_login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/login.png"))); // NOI18N
        btn_login.setText("Login");
        btn_login.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_login.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });
        loginPage.add(btn_login, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 520, 130, 40));

        btn_exit.setBackground(new java.awt.Color(0, 102, 102));
        btn_exit.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(255, 255, 255));
        btn_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/exit.png"))); // NOI18N
        btn_exit.setText("Exit");
        btn_exit.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_exit.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });
        loginPage.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 520, 130, 40));

        btn_signup.setBackground(new java.awt.Color(0, 102, 102));
        btn_signup.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_signup.setForeground(new java.awt.Color(255, 255, 255));
        btn_signup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/signup.png"))); // NOI18N
        btn_signup.setText("Signup");
        btn_signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_signupActionPerformed(evt);
            }
        });
        loginPage.add(btn_signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 520, -1, -1));

        txt_userName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_userNameKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_userNameKeyReleased(evt);
            }
        });
        loginPage.add(txt_userName, new org.netbeans.lib.awtextra.AbsoluteConstraints(185, 205, 200, 35));

        txt_password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_passwordKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_passwordKeyReleased(evt);
            }
        });
        loginPage.add(txt_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(185, 295, 200, 35));

        alertPassword.setEditable(false);
        alertPassword.setBackground(new java.awt.Color(0, 153, 153));
        alertPassword.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertPassword.setForeground(new java.awt.Color(102, 51, 0));
        alertPassword.setText("Enter your password");
        alertPassword.setBorder(null);
        loginPage.add(alertPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 300, 140, 20));

        alertUserName.setEditable(false);
        alertUserName.setBackground(new java.awt.Color(0, 153, 153));
        alertUserName.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertUserName.setForeground(new java.awt.Color(102, 51, 0));
        alertUserName.setText("Enter your username");
        alertUserName.setBorder(null);
        loginPage.add(alertUserName, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 210, 140, 20));

        separator3.setBackground(new java.awt.Color(0, 0, 0));
        separator3.setForeground(new java.awt.Color(0, 0, 0));
        loginPage.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 132, 548, 5));

        mainLoginPanel.add(loginPage, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 2, 548, 646));

        loginImageLabel.setBackground(new java.awt.Color(255, 255, 255));
        loginImageLabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        loginImageLabel.setForeground(new java.awt.Color(255, 255, 255));
        loginImageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BgIcons/Login background.png"))); // NOI18N
        mainLoginPanel.add(loginImageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 698, 646));

        getContentPane().add(mainLoginPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
         Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
        String userName=txt_userName.getText();
        String password=txt_password.getText();
            userVerification(userName,password);     
    }//GEN-LAST:event_btn_loginActionPerformed

    private void btn_signupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_signupActionPerformed
          SignupPage signup = new SignupPage();
          signup.show();
          this.dispose();
    }//GEN-LAST:event_btn_signupActionPerformed

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btn_exitActionPerformed

    private void txt_userNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_userNameKeyReleased
       if(txt_userName.getText().length()==0)
            alertUserName.setText("Enter your username");
        else
            alertUserName.setText("");
    }//GEN-LAST:event_txt_userNameKeyReleased

    private void txt_passwordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passwordKeyPressed
        if(txt_password.getText().length()==0)
            alertPassword.setText("Enter your password");
        else
            alertPassword.setText("");
    }//GEN-LAST:event_txt_passwordKeyPressed

    private void txt_passwordKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passwordKeyReleased
         if(txt_password.getText().length()==0)
            alertPassword.setText("Enter your password");
        else
            alertPassword.setText("");
    }//GEN-LAST:event_txt_passwordKeyReleased

    private void txt_userNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_userNameKeyPressed
        if(txt_userName.getText().length()==0)
            alertUserName.setText("Enter your username");
        else
            alertUserName.setText("");
    }//GEN-LAST:event_txt_userNameKeyPressed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JTextField alertPassword;
    private javax.swing.JTextField alertUserName;
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_login;
    private javax.swing.JButton btn_signup;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel loginAccountLabel;
    private javax.swing.JLabel loginImageLabel;
    private javax.swing.JPanel loginPage;
    private javax.swing.JLabel loginPageLabel;
    private javax.swing.JPanel mainLoginPanel;
    private javax.swing.JLabel passwordLabel;
    private javax.swing.JSeparator separator3;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_userName;
    private javax.swing.JLabel userNameLabel;
    // End of variables declaration//GEN-END:variables
}
