
package Fees_Management_System;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.Year;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class EditCourse extends javax.swing.JFrame {

    DefaultTableModel model;
    String courseIdMain;
    public EditCourse() {
        initComponents();
        setRecordToTable();
        resetCourse();
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainAddFeesPanel = new javax.swing.JPanel();
        leftPanel = new javax.swing.JPanel();
        home = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        searchRecord = new javax.swing.JPanel();
        searchRecordLabel = new javax.swing.JLabel();
        viewCourse = new javax.swing.JPanel();
        viewCourseLabel = new javax.swing.JLabel();
        addFees = new javax.swing.JPanel();
        addFeesLabel = new javax.swing.JLabel();
        viewReport = new javax.swing.JPanel();
        viewReportLabel = new javax.swing.JLabel();
        Logout = new javax.swing.JPanel();
        logoutLabel = new javax.swing.JLabel();
        rightPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_courseData = new javax.swing.JTable();
        serchRecord = new javax.swing.JLabel();
        separator3 = new javax.swing.JSeparator();
        txt_courseId = new javax.swing.JTextField();
        courseId = new javax.swing.JLabel();
        couseName = new javax.swing.JLabel();
        txt_courseName = new javax.swing.JTextField();
        coursePrice = new javax.swing.JLabel();
        txt_coursePrice = new javax.swing.JTextField();
        btn_add = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        btn_reset = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("AddFeesFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainAddFeesPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainAddFeesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        leftPanel.setBackground(new java.awt.Color(0, 102, 102));
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        home.setBackground(new java.awt.Color(0, 102, 102));
        home.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                homeMouseExited(evt);
            }
        });

        homeLabel.setBackground(new java.awt.Color(0, 102, 102));
        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        homeLabel.setForeground(new java.awt.Color(255, 255, 255));
        homeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Home.png"))); // NOI18N
        homeLabel.setText("Home");

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(homeLabel)
                .addContainerGap(89, Short.MAX_VALUE))
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homeLayout.createSequentialGroup()
                .addComponent(homeLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 205, 54));

        searchRecord.setBackground(new java.awt.Color(0, 102, 102));
        searchRecord.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchRecordMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                searchRecordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                searchRecordMouseExited(evt);
            }
        });

        searchRecordLabel.setBackground(new java.awt.Color(0, 102, 102));
        searchRecordLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchRecordLabel.setForeground(new java.awt.Color(255, 255, 255));
        searchRecordLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/SearchRecord.png"))); // NOI18N
        searchRecordLabel.setText("Search Record");

        javax.swing.GroupLayout searchRecordLayout = new javax.swing.GroupLayout(searchRecord);
        searchRecord.setLayout(searchRecordLayout);
        searchRecordLayout.setHorizontalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchRecordLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchRecordLabel)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        searchRecordLayout.setVerticalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, searchRecordLayout.createSequentialGroup()
                .addComponent(searchRecordLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(searchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 144, 205, 54));

        viewCourse.setBackground(new java.awt.Color(0, 102, 102));
        viewCourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewCourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewCourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewCourseMouseExited(evt);
            }
        });

        viewCourseLabel.setBackground(new java.awt.Color(0, 102, 102));
        viewCourseLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        viewCourseLabel.setForeground(new java.awt.Color(255, 255, 255));
        viewCourseLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/CourseList.png"))); // NOI18N
        viewCourseLabel.setText("View Course");

        javax.swing.GroupLayout viewCourseLayout = new javax.swing.GroupLayout(viewCourse);
        viewCourse.setLayout(viewCourseLayout);
        viewCourseLayout.setHorizontalGroup(
            viewCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(viewCourseLabel)
                .addContainerGap(36, Short.MAX_VALUE))
        );
        viewCourseLayout.setVerticalGroup(
            viewCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewCourseLayout.createSequentialGroup()
                .addComponent(viewCourseLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(viewCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 228, 205, 54));

        addFees.setBackground(new java.awt.Color(0, 102, 102));
        addFees.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addFees.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addFeesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addFeesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addFeesMouseExited(evt);
            }
        });

        addFeesLabel.setBackground(new java.awt.Color(0, 102, 102));
        addFeesLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        addFeesLabel.setForeground(new java.awt.Color(255, 255, 255));
        addFeesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/AddFees.png"))); // NOI18N
        addFeesLabel.setText("Add Fees");

        javax.swing.GroupLayout addFeesLayout = new javax.swing.GroupLayout(addFees);
        addFees.setLayout(addFeesLayout);
        addFeesLayout.setHorizontalGroup(
            addFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addFeesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(addFeesLabel)
                .addContainerGap(64, Short.MAX_VALUE))
        );
        addFeesLayout.setVerticalGroup(
            addFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addFeesLayout.createSequentialGroup()
                .addComponent(addFeesLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(addFees, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 312, 205, 54));

        viewReport.setBackground(new java.awt.Color(0, 102, 102));
        viewReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewReportMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewReportMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewReportMouseExited(evt);
            }
        });

        viewReportLabel.setBackground(new java.awt.Color(0, 102, 102));
        viewReportLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        viewReportLabel.setForeground(new java.awt.Color(255, 255, 255));
        viewReportLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/ViewAllRecord.png"))); // NOI18N
        viewReportLabel.setText("View Report");

        javax.swing.GroupLayout viewReportLayout = new javax.swing.GroupLayout(viewReport);
        viewReport.setLayout(viewReportLayout);
        viewReportLayout.setHorizontalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewReportLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(viewReportLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        viewReportLayout.setVerticalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewReportLayout.createSequentialGroup()
                .addComponent(viewReportLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(viewReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 396, 205, 54));
        viewReport.getAccessibleContext().setAccessibleDescription("");

        Logout.setBackground(new java.awt.Color(0, 102, 102));
        Logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                LogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                LogoutMouseExited(evt);
            }
        });

        logoutLabel.setBackground(new java.awt.Color(0, 102, 102));
        logoutLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Logout.png"))); // NOI18N
        logoutLabel.setText("Logout");

        javax.swing.GroupLayout LogoutLayout = new javax.swing.GroupLayout(Logout);
        Logout.setLayout(LogoutLayout);
        LogoutLayout.setHorizontalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LogoutLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoutLabel)
                .addContainerGap(85, Short.MAX_VALUE))
        );
        LogoutLayout.setVerticalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LogoutLayout.createSequentialGroup()
                .addComponent(logoutLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 480, 210, 54));

        mainAddFeesPanel.add(leftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 350, 646));

        rightPanel.setBackground(new java.awt.Color(0, 153, 153));
        rightPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        rightPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(838, 0, 60, -1));

        tbl_courseData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course Id", "Course Name", "Course Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_courseData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_courseDataMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_courseData);

        rightPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 480, 550));

        serchRecord.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        serchRecord.setForeground(new java.awt.Color(255, 255, 255));
        serchRecord.setText("Edit Course Details");
        rightPanel.add(serchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(273, 0, 320, 40));

        separator3.setForeground(new java.awt.Color(0, 0, 0));
        rightPanel.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 896, 5));

        txt_courseId.setEditable(false);
        txt_courseId.setForeground(new java.awt.Color(255, 255, 255));
        txt_courseId.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txt_courseId.setEnabled(false);
        rightPanel.add(txt_courseId, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 205, 200, 35));

        courseId.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        courseId.setForeground(new java.awt.Color(255, 255, 255));
        courseId.setText("Course Id:");
        rightPanel.add(courseId, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 210, 160, 25));

        couseName.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        couseName.setForeground(new java.awt.Color(255, 255, 255));
        couseName.setText("Course Name:");
        rightPanel.add(couseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 270, 160, 25));
        rightPanel.add(txt_courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 265, 200, 35));

        coursePrice.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        coursePrice.setForeground(new java.awt.Color(255, 255, 255));
        coursePrice.setText("Course Price:");
        rightPanel.add(coursePrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 330, 160, 25));
        rightPanel.add(txt_coursePrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 325, 200, 35));

        btn_add.setBackground(new java.awt.Color(0, 102, 102));
        btn_add.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_add.setForeground(new java.awt.Color(255, 255, 255));
        btn_add.setText("ADD");
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });
        rightPanel.add(btn_add, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 520, 120, 40));

        btn_delete.setBackground(new java.awt.Color(0, 102, 102));
        btn_delete.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_delete.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete.setText("Delete");
        btn_delete.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_delete.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        rightPanel.add(btn_delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 520, 120, 40));

        btn_reset.setBackground(new java.awt.Color(0, 102, 102));
        btn_reset.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_reset.setForeground(new java.awt.Color(255, 255, 255));
        btn_reset.setText("RESET");
        btn_reset.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_reset.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });
        rightPanel.add(btn_reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 460, 120, 40));

        btn_update.setBackground(new java.awt.Color(0, 102, 102));
        btn_update.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_update.setForeground(new java.awt.Color(255, 255, 255));
        btn_update.setText("UPDATE");
        btn_update.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_update.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        rightPanel.add(btn_update, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 520, 120, 40));

        mainAddFeesPanel.add(rightPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 2, 896, 646));

        getContentPane().add(mainAddFeesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
   public void setRecordToTable()
   {
        try
        {
            Connection con =DBConnection.getConnection();
            PreparedStatement pst=con.prepareStatement("select * from course");
            ResultSet rs=pst.executeQuery();
            while(rs.next())
            {
                String id = "COID-"+rs.getString("id");
                String courseName=rs.getString("courseName");
                String coursePrice=rs.getString("coursePrice");
                Object[] obj ={id,courseName,coursePrice};
                model = (DefaultTableModel)tbl_courseData.getModel();
                model.addRow(obj); 
            }
        }
         catch(Exception e)
        {
            e.printStackTrace();
        }  
   }
   void resetCourse()
   {
        int courseId=0;
         try
            {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst=con.prepareStatement("select max(id) from course");
              ResultSet rs=pst.executeQuery();
              if(rs.next()==true)
              {
                  courseId=rs.getInt("max(id)");
                  courseId+=1;  
                  courseIdMain="COID-"+Integer.toString(courseId);
                  txt_courseId.setText(courseIdMain);
              }
            } 
        catch(Exception e)
            {
                e.printStackTrace();
            }
         txt_courseName.setText("");
         txt_coursePrice.setText("");
   }
   boolean deleteCourse()
   {
            boolean isDeleted = false;
            int courseId = Integer.parseInt(txt_courseId.getText().substring(5));
            try
            {
                Connection con = DBConnection.getConnection();
                String sql = "delete from course where id = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setInt(1, courseId);
                int rowCount = pst.executeUpdate();
                if(rowCount > 0)
                    isDeleted = true;
                else
                    isDeleted = false;
            }catch(Exception e)
            {
                e.printStackTrace();
            }
            return isDeleted;
   }  
   //to update course details 
    public boolean updateCourse()
    {
          boolean isUpdated = false;
          int courseId = Integer.parseInt(txt_courseId.getText().substring(5));
          String courseName = txt_courseName.getText();
          String courseCost = txt_coursePrice.getText();
          try
          {
              Connection con = DBConnection.getConnection();
              String sql = "update course set courseName = ?,coursePrice = ? where id = ?";
              PreparedStatement  pst = con.prepareStatement(sql);
              pst.setString(1, courseName);
              pst.setString(2,courseCost);
              pst.setInt(3,courseId);
               
              int rowCount = pst.executeUpdate();
              if(rowCount > 0)
                  isUpdated = true;
              else
                  isUpdated = false;
          }catch(Exception e)
          {
              e.printStackTrace();
          }
          return isUpdated;
    } 
    //to add book to book deatails table
      public boolean addCourse()
     {
        boolean isAdded = false;
          int courseId = Integer.parseInt(txt_courseId.getText().substring(5));
          String courseName = txt_courseName.getText();
          String courseCost = txt_coursePrice.getText();
          try
          {
              Connection con =  DBConnection.getConnection();
              String sql="insert into course(courseName,coursePrice) values(?,?)";
              PreparedStatement pst = con.prepareStatement(sql);
              pst.setString(1, courseName);
              pst.setString(2,courseCost);
              int rowCount = pst.executeUpdate();
              if(rowCount > 0)
                  isAdded = true;
              else
                  isAdded = false;
          }
          catch(Exception e)
          {
              e.printStackTrace();
          }
          return isAdded;
       }
   //method clear table
        public void clearTable()
        {
            DefaultTableModel model = (DefaultTableModel) tbl_courseData.getModel();
            model.setRowCount(0);
        }
      //course check empty
       boolean isEmpty()
       {
           boolean isempty=true;
           if(txt_courseName.getText().equals(""))
             JOptionPane.showMessageDialog(this,"Please enter course name");
           else
            if(txt_coursePrice.getText().equals(""))
             JOptionPane.showMessageDialog(this,"Please enter course price");  
           else
            if(txt_coursePrice.getText().matches("^[0-9]*$")==false) 
              JOptionPane.showMessageDialog(this,"Course Price - Only digit allow");     
           else
             isempty=false;
           return isempty;
       }       
    private void homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseEntered
        Color clr=new Color(0,153,153);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseEntered

    private void homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseExited
        Color clr=new Color(0,102,102);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseExited

    private void searchRecordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseEntered
        Color clr=new Color(0,153,153);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseEntered

    private void searchRecordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseExited
        Color clr=new Color(0,102,102);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseExited

    private void viewCourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewCourseMouseEntered
        Color clr=new Color(0,153,153);
        viewCourse.setBackground(clr);
    }//GEN-LAST:event_viewCourseMouseEntered

    private void viewCourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewCourseMouseExited
          Color clr=new Color(0,102,102);
          viewCourse.setBackground(clr);
    }//GEN-LAST:event_viewCourseMouseExited

    private void addFeesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseEntered
          Color clr=new Color(0,153,153);
          addFees.setBackground(clr);
    }//GEN-LAST:event_addFeesMouseEntered

    private void addFeesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseExited
          Color clr=new Color(0,102,102);
          addFees.setBackground(clr);
    }//GEN-LAST:event_addFeesMouseExited

    private void viewReportMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseEntered
          Color clr=new Color(0,153,153);
          viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseEntered

    private void viewReportMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseExited
          Color clr=new Color(0,102,102);
          viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseExited

    private void LogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseEntered
          Color clr=new Color(0,153,153);
          Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseEntered

    private void LogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseExited
          Color clr=new Color(0,102,102);
          Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseExited

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void tbl_courseDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_courseDataMouseClicked
        int rowNo=tbl_courseData.getSelectedRow();
        TableModel model=tbl_courseData.getModel();
        txt_courseId.setText(model.getValueAt(rowNo,0).toString());
        txt_courseName.setText(model.getValueAt(rowNo,1).toString());
        txt_coursePrice.setText(model.getValueAt(rowNo,2).toString());
    }//GEN-LAST:event_tbl_courseDataMouseClicked

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        resetCourse();
    }//GEN-LAST:event_btn_resetActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        if(deleteCourse()==true)
        {   
            JOptionPane.showMessageDialog(this,"Course deleted");
            clearTable();
            setRecordToTable();
            resetCourse();
        }    
        else
            JOptionPane.showMessageDialog(this,"Course id Doesn't Exist");
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        if(isEmpty()==false)
        if(updateCourse()==true)
        {
            JOptionPane.showMessageDialog(this,"Course updated");
            clearTable();
            setRecordToTable();
            resetCourse();
        }   
        else
         JOptionPane.showMessageDialog(this,"Course id or Doesn't Exist");   
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        if( courseIdMain.equals(txt_courseId.getText())==false)
        {    
           JOptionPane.showMessageDialog(this,"Course Id already Exist");
           JOptionPane.showMessageDialog(this,"Please click reset button and try again");
        }   
        else
         if(isEmpty()==false)  
         if(addCourse()==true)
        {
            JOptionPane.showMessageDialog(this,"Course added successfully");
            clearTable();
            setRecordToTable();
            resetCourse();
        } 
        else
             JOptionPane.showMessageDialog(this,"Course addition failure");   
    }//GEN-LAST:event_btn_addActionPerformed

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
         LoginPage login = new LoginPage();
        login.show();
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    private void viewReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseClicked
        ViewReport report= new ViewReport();
       report.show();
       this.dispose();
    }//GEN-LAST:event_viewReportMouseClicked

    private void addFeesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseClicked
       AddFees add= new AddFees();
       add.show();
       this.dispose();
    }//GEN-LAST:event_addFeesMouseClicked

    private void viewCourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewCourseMouseClicked
        ViewCourse view = new ViewCourse();
        view.show();
        this.dispose();
    }//GEN-LAST:event_viewCourseMouseClicked

    private void searchRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseClicked
        SearchRecord search=new SearchRecord();
       search.show();
       this.dispose();
    }//GEN-LAST:event_searchRecordMouseClicked

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        HomePage home=new HomePage();
        home.show();
        this.dispose();
    }//GEN-LAST:event_homeMouseClicked

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditCourse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditCourse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditCourse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditCourse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
     

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditCourse().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JPanel Logout;
    private javax.swing.JPanel addFees;
    private javax.swing.JLabel addFeesLabel;
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_update;
    private javax.swing.JLabel courseId;
    private javax.swing.JLabel coursePrice;
    private javax.swing.JLabel couseName;
    private javax.swing.JPanel exitButton;
    private javax.swing.JPanel home;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JPanel mainAddFeesPanel;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JPanel searchRecord;
    private javax.swing.JLabel searchRecordLabel;
    private javax.swing.JSeparator separator3;
    private javax.swing.JLabel serchRecord;
    private javax.swing.JTable tbl_courseData;
    private javax.swing.JTextField txt_courseId;
    private javax.swing.JTextField txt_courseName;
    private javax.swing.JTextField txt_coursePrice;
    private javax.swing.JPanel viewCourse;
    private javax.swing.JLabel viewCourseLabel;
    private javax.swing.JPanel viewReport;
    private javax.swing.JLabel viewReportLabel;
    // End of variables declaration//GEN-END:variables
}
