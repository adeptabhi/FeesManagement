package Fees_Management_System;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.Year;
import java.util.Date;
import javax.swing.JOptionPane;

public class AddFees extends javax.swing.JFrame {

    /**
     * Creates new form AddFees
     */
    public AddFees() {
        initComponents();
        initialization();
    } 
    public void initialization()
    {
        //for  Registration list
        try
            {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst1= con.prepareStatement("select id from studentDetails");
              ResultSet rs1=pst1.executeQuery();
              while(rs1.next())
              {
                   PreparedStatement pst2= con.prepareStatement("select registrationNo from feesDetails where registrationNo=?");
                   pst2.setInt(1,rs1.getInt("id"));
                   ResultSet rs2=pst2.executeQuery();
                   while(!rs2.next())
                   {    
                     txt_registrationNo.addItem("UIETRS-"+rs1.getString("id"));
                     break;
                   } 
              }
            } 
        catch(Exception e)
         {            
                e.printStackTrace();
          } 
        if(checkFeesDue()==true)
        {    
          //for receipt No
          int receiptNo=0;
          try
            {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst=con.prepareStatement("select max(id) from feesdetails");
              ResultSet rs=pst.executeQuery();
              if(rs.next()==true)
              {
                  receiptNo=rs.getInt("max(id)");
                  receiptNo+=1;
                  txt_receiptNo.setText("UIETFR-"+Integer.toString(receiptNo));  
              }
            } 
        catch(Exception e)
            {
                e.printStackTrace();
            }

        ddNo.setVisible(true);
        chequeNoEnter.setVisible(false);
        ddNoEnter.setVisible(true);
        chequeNo.setVisible(false);
        bankName.setVisible(true);
        bankNameSelect.setVisible(true);
        txt_ddNo.setVisible(true);
        txt_chequeNo.setVisible(false);
        txt_bankName.setVisible(true);
         SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
         Date date = new Date();
         txt_date.setText(formatter.format(date));
         Year year = Year.now();
         txt_yearFrom.setText(String.valueOf(year));
         String str=String.valueOf(year);
         int yearInt=Integer.parseInt(str);
         txt_yearTo.setText(String.valueOf(yearInt+1));
         studentNameCourseNameAmount();
        } 
    }
      boolean checkFeesDue()
    {
        if(txt_registrationNo.getSelectedIndex()==-1)
        {    
            rightPanel.setVisible(false);
            noDueFees.setVisible(true);
        }   
        else
        {
            rightPanel.setVisible(true);
            noDueFees.setVisible(false);
            return true;
        }    
        return false;    
    } 
    void studentNameCourseNameAmount()
    {
         try
        {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst= con.prepareStatement("select courseName,firstName,lastName,coursePrice from studentDetails where id=? limit 1");
              pst.setInt(1,Integer.parseInt(txt_registrationNo.getSelectedItem().toString().substring(7)));
              ResultSet rs=pst.executeQuery();
              if(rs.next())
              {
                txt_courseName.setText(rs.getString("courseName"));
                txt_studentName.setText(rs.getString("firstName")+" "+rs.getString("lastName"));
                txt_amount.setText(rs.getString("coursePrice"));
                calculateTax();
              }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        } 
    }        
    void calculateTax()
    {
         if(!txt_amount.getText().equals(""))
        {
            float amount=Float.parseFloat(txt_amount.getText());
            float cgst=amount*0.09f;
            float sgst=amount*0.09f;
            txt_cgst.setText(Float.toString(cgst));
            txt_sgst.setText(Float.toString(sgst));
            float total=amount+cgst+sgst;
            txt_total.setText(Float.toString(total));
            txt_totalInWords.setText(NumberToWordsConverter.convert((int)total));
        }
    }
    boolean validation()
    {
        if(txt_paymentMode.getSelectedIndex()==0)
        {
          if(txt_ddNo.getText().length()==0)
              return false;
        }  
        else
        if(txt_paymentMode.getSelectedIndex()==1)
        {
            if(txt_chequeNo.getText().length()==0)
              return false;
        }    
        return true;
    }
    public boolean insertData()
    {
        Date date  = Date.from(Instant.now().plusSeconds(0)); 
          long dateLong = date.getTime(); 
          java.sql.Date sqlDate = new java.sql.Date(dateLong);
        String paymentMode=txt_paymentMode.getSelectedItem().toString();
        String gstin=txt_gstin.getText();
        String ddNo=txt_ddNo.getText();
        String chequeNo=txt_chequeNo.getText();
        String bankName;
          if(txt_paymentMode.getSelectedIndex()==2)
                bankName="";
          else              
                bankName=txt_bankName.getSelectedItem().toString();
        int registrationNo=Integer.parseInt(txt_registrationNo.getSelectedItem().toString().substring(7));
        String studentName = txt_studentName.getText();
        String courseName = txt_courseName.getText();
        int yearFrom=Integer.parseInt(txt_yearFrom.getText());
        int yearTo=Integer.parseInt(txt_yearTo.getText());
        float amount=Float.parseFloat(txt_amount.getText());
        float cgst =Float.parseFloat(txt_cgst.getText());
        float sgst=Float.parseFloat(txt_sgst.getText());
        float total = Float.parseFloat(txt_total.getText());
        String totalInWords=txt_totalInWords.getText();
        String remarks=txt_remarks.getText();
         try   
         {    
              Connection con=DBConnection.getConnection();
              PreparedStatement pst= con.prepareStatement("insert into feesDetails (date,gstin,paymentMode,ddNo,chequeNo,bankName,registrationNo,studentName,courseName,yearFrom,yearTo,amount,cgst,sgst,total,totalInWords,remark) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
              pst.setDate(1,sqlDate);
              pst.setString(2,gstin);
              pst.setString(3,paymentMode);
              pst.setString(4, ddNo);
              pst.setString(5, chequeNo);
              pst.setString(6, bankName);
              pst.setInt(7,registrationNo);
              pst.setString(8, studentName);
              pst.setString(9,courseName );
              pst.setInt(10,yearFrom);
              pst.setInt(11,yearTo);
              pst.setFloat(12, amount);
              pst.setFloat(13, cgst);
              pst.setFloat(14, sgst);
              pst.setFloat(15, total);
              pst.setString(16,totalInWords);
              pst.setString(17,remarks );
              int rowCount=pst.executeUpdate();
              if(rowCount==1)
                  return true;
         }   
           catch(Exception e)
           {
               e.printStackTrace();
            } 
         return false;
        } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainAddFeesPanel = new javax.swing.JPanel();
        leftPanel = new javax.swing.JPanel();
        home = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        searchRecord = new javax.swing.JPanel();
        searchRecordLabel = new javax.swing.JLabel();
        editCourse = new javax.swing.JPanel();
        editCourseLabel = new javax.swing.JLabel();
        courseList = new javax.swing.JPanel();
        courseListLabel = new javax.swing.JLabel();
        viewReport = new javax.swing.JPanel();
        viewReportLabel = new javax.swing.JLabel();
        Logout = new javax.swing.JPanel();
        logoutLabel = new javax.swing.JLabel();
        rightPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        modeOfPayment = new javax.swing.JLabel();
        ddNo = new javax.swing.JLabel();
        chequeNo = new javax.swing.JLabel();
        ReceiptNoUiet = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        gstin = new javax.swing.JLabel();
        txt_ddNo = new app.bolivia.swing.JCTextField();
        txt_chequeNo = new app.bolivia.swing.JCTextField();
        bankName = new javax.swing.JLabel();
        txt_bankName = new javax.swing.JComboBox<>();
        txt_paymentMode = new javax.swing.JComboBox<>();
        rollNo = new javax.swing.JLabel();
        txt_courseName = new app.bolivia.swing.JCTextField();
        txt_registrationNo = new javax.swing.JComboBox<>();
        course = new javax.swing.JLabel();
        thePaymentYear = new javax.swing.JLabel();
        to = new javax.swing.JLabel();
        studentName = new javax.swing.JLabel();
        txt_studentName = new app.bolivia.swing.JCTextField();
        upSeparator = new javax.swing.JSeparator();
        heads = new javax.swing.JLabel();
        amountRs = new javax.swing.JLabel();
        totalSeparator = new javax.swing.JSeparator();
        courseFee = new javax.swing.JLabel();
        cgst = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        txt_remarks = new app.bolivia.swing.JCTextField();
        remarks = new javax.swing.JLabel();
        totalInWords1 = new javax.swing.JLabel();
        btn_print = new javax.swing.JButton();
        sgst = new javax.swing.JLabel();
        downSeparator = new javax.swing.JSeparator();
        txt_total = new javax.swing.JTextField();
        txt_amount = new javax.swing.JTextField();
        txt_cgst = new javax.swing.JTextField();
        txt_sgst = new javax.swing.JTextField();
        txt_totalInWords = new app.bolivia.swing.JCTextField();
        txt_yearTo = new javax.swing.JTextField();
        txt_yearFrom = new javax.swing.JTextField();
        txt_date = new javax.swing.JTextField();
        txt_gstin = new javax.swing.JTextField();
        txt_receiptNo = new javax.swing.JTextField();
        paymentModeSelect = new javax.swing.JTextField();
        bankNameSelect = new javax.swing.JTextField();
        ddNoEnter = new javax.swing.JTextField();
        registrationNoSelect = new javax.swing.JTextField();
        chequeNoEnter = new javax.swing.JTextField();
        noDueFeesPanel = new javax.swing.JPanel();
        noDueFees = new javax.swing.JLabel();
        exitButtonDue = new javax.swing.JPanel();
        ExitButtonLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("AddFeesFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainAddFeesPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainAddFeesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        leftPanel.setBackground(new java.awt.Color(0, 102, 102));
        leftPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                leftPanelMouseClicked(evt);
            }
        });
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        home.setBackground(new java.awt.Color(0, 102, 102));
        home.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                homeMouseExited(evt);
            }
        });

        homeLabel.setBackground(new java.awt.Color(0, 102, 102));
        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        homeLabel.setForeground(new java.awt.Color(255, 255, 255));
        homeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Home.png"))); // NOI18N
        homeLabel.setText("Home");

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(homeLabel)
                .addContainerGap(89, Short.MAX_VALUE))
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homeLayout.createSequentialGroup()
                .addComponent(homeLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 205, 54));

        searchRecord.setBackground(new java.awt.Color(0, 102, 102));
        searchRecord.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchRecordMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                searchRecordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                searchRecordMouseExited(evt);
            }
        });

        searchRecordLabel.setBackground(new java.awt.Color(0, 102, 102));
        searchRecordLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchRecordLabel.setForeground(new java.awt.Color(255, 255, 255));
        searchRecordLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/SearchRecord.png"))); // NOI18N
        searchRecordLabel.setText("Search Record");

        javax.swing.GroupLayout searchRecordLayout = new javax.swing.GroupLayout(searchRecord);
        searchRecord.setLayout(searchRecordLayout);
        searchRecordLayout.setHorizontalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchRecordLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchRecordLabel)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        searchRecordLayout.setVerticalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, searchRecordLayout.createSequentialGroup()
                .addComponent(searchRecordLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(searchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 144, 205, 54));

        editCourse.setBackground(new java.awt.Color(0, 102, 102));
        editCourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editCourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                editCourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                editCourseMouseExited(evt);
            }
        });

        editCourseLabel.setBackground(new java.awt.Color(0, 102, 102));
        editCourseLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        editCourseLabel.setForeground(new java.awt.Color(255, 255, 255));
        editCourseLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/EditCourse.png"))); // NOI18N
        editCourseLabel.setText("Edit Course");

        javax.swing.GroupLayout editCourseLayout = new javax.swing.GroupLayout(editCourse);
        editCourse.setLayout(editCourseLayout);
        editCourseLayout.setHorizontalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editCourseLabel)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        editCourseLayout.setVerticalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editCourseLayout.createSequentialGroup()
                .addComponent(editCourseLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(editCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 228, 205, 54));

        courseList.setBackground(new java.awt.Color(0, 102, 102));
        courseList.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        courseList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                courseListMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                courseListMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                courseListMouseExited(evt);
            }
        });

        courseListLabel.setBackground(new java.awt.Color(0, 102, 102));
        courseListLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        courseListLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseListLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/CourseList.png"))); // NOI18N
        courseListLabel.setText("Course List");

        javax.swing.GroupLayout courseListLayout = new javax.swing.GroupLayout(courseList);
        courseList.setLayout(courseListLayout);
        courseListLayout.setHorizontalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(courseListLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(courseListLabel)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        courseListLayout.setVerticalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, courseListLayout.createSequentialGroup()
                .addComponent(courseListLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(courseList, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 312, 205, 54));

        viewReport.setBackground(new java.awt.Color(0, 102, 102));
        viewReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewReportMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewReportMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewReportMouseExited(evt);
            }
        });

        viewReportLabel.setBackground(new java.awt.Color(0, 102, 102));
        viewReportLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        viewReportLabel.setForeground(new java.awt.Color(255, 255, 255));
        viewReportLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/ViewAllRecord.png"))); // NOI18N
        viewReportLabel.setText("View Report");

        javax.swing.GroupLayout viewReportLayout = new javax.swing.GroupLayout(viewReport);
        viewReport.setLayout(viewReportLayout);
        viewReportLayout.setHorizontalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewReportLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(viewReportLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        viewReportLayout.setVerticalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewReportLayout.createSequentialGroup()
                .addComponent(viewReportLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(viewReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 396, 205, 54));
        viewReport.getAccessibleContext().setAccessibleDescription("");

        Logout.setBackground(new java.awt.Color(0, 102, 102));
        Logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                LogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                LogoutMouseExited(evt);
            }
        });

        logoutLabel.setBackground(new java.awt.Color(0, 102, 102));
        logoutLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Logout.png"))); // NOI18N
        logoutLabel.setText("Logout");

        javax.swing.GroupLayout LogoutLayout = new javax.swing.GroupLayout(Logout);
        Logout.setLayout(LogoutLayout);
        LogoutLayout.setHorizontalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LogoutLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoutLabel)
                .addContainerGap(85, Short.MAX_VALUE))
        );
        LogoutLayout.setVerticalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LogoutLayout.createSequentialGroup()
                .addComponent(logoutLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 480, 210, 54));

        mainAddFeesPanel.add(leftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 350, 646));

        rightPanel.setBackground(new java.awt.Color(0, 153, 153));
        rightPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        rightPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(838, 0, 60, -1));

        modeOfPayment.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        modeOfPayment.setText("Mode of Payment:");
        rightPanel.add(modeOfPayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 125, 20));

        ddNo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ddNo.setText("DD No:");
        rightPanel.add(ddNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 95, 125, 20));

        chequeNo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        chequeNo.setText("Cheque No:");
        rightPanel.add(chequeNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 95, 125, 20));

        ReceiptNoUiet.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ReceiptNoUiet.setText("Receipt No UIET: ");
        rightPanel.add(ReceiptNoUiet, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 25, 125, 20));

        date.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        date.setText("Date:");
        rightPanel.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 25, 70, 20));

        gstin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        gstin.setText("GSTIN:");
        rightPanel.add(gstin, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 60, 70, 20));
        rightPanel.add(txt_ddNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 200, 30));
        rightPanel.add(txt_chequeNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 200, 30));

        bankName.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bankName.setText("Bank Name:");
        rightPanel.add(bankName, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 125, 20));

        txt_bankName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Allahabad Bank", "Andhra Bank", "Axis Bank", "Bank of Bahrain and Kuwait", "Bank of Baroda - Corporate Banking", "Bank of Baroda - Retail Banking", "Bank of India", "Bank of Maharashtra", "Canara Bank", "Central Bank of India", "City Union Bank", "Corporation Bank", "Deutsche Bank", "Development Credit Bank", "Dhanlaxmi Bank", "Federal Bank", "ICICI Bank", "IDBI Bank", "Indian Bank", "Indian Overseas Bank", "IndusInd Bank", "ING Vysya Bank", "Jammu and Kashmir Bank", "Karnataka Bank Ltd", "Karur Vysya Bank", "Kotak Bank", "Laxmi Vilas Bank", "Oriental Bank of Commerce", "Punjab National Bank - Corporate Banking", "Punjab National Bank - Retail Banking", "Punjab & Sind Bank", "Shamrao Vitthal Co-operative Bank", "South Indian Bank", "State Bank of Bikaner & Jaipur", "State Bank of Hyderabad", "State Bank of India", "State Bank of Mysore", "State Bank of Patiala", "State Bank of Travancore", "Syndicate Bank", "Tamilnad Mercantile Bank Ltd.", "UCO Bank", "Union Bank of India", "United Bank of India", "Vijaya Bank", "Yes Bank Ltd" }));
        rightPanel.add(txt_bankName, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 125, 200, 30));

        txt_paymentMode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DD", "Cheque", "Cash", "Card" }));
        txt_paymentMode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_paymentModeActionPerformed(evt);
            }
        });
        rightPanel.add(txt_paymentMode, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 55, 200, 30));

        rollNo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        rollNo.setText("Registration No:");
        rightPanel.add(rollNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 165, 125, 20));

        txt_courseName.setEditable(false);
        txt_courseName.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 200, 30));

        txt_registrationNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_registrationNoActionPerformed(evt);
            }
        });
        rightPanel.add(txt_registrationNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 200, 30));

        course.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        course.setText("Course Name:");
        rightPanel.add(course, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 235, 125, 20));

        thePaymentYear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        thePaymentYear.setText("The following paymentin the college office for the year:");
        rightPanel.add(thePaymentYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 370, 20));

        to.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        to.setText("To");
        rightPanel.add(to, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 270, 20, 20));

        studentName.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        studentName.setText("Student Name:");
        rightPanel.add(studentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 125, 20));

        txt_studentName.setEditable(false);
        txt_studentName.setAlignmentX(3.0F);
        txt_studentName.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_studentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 195, 200, 30));
        rightPanel.add(upSeparator, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 315, 796, 7));

        heads.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        heads.setText("Head:");
        rightPanel.add(heads, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 100, 20));

        amountRs.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        amountRs.setText("Amount (Rs):");
        rightPanel.add(amountRs, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 330, 100, 20));
        rightPanel.add(totalSeparator, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 485, 796, 7));

        courseFee.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        courseFee.setText("Course Fee");
        rightPanel.add(courseFee, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 380, 150, 20));

        cgst.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cgst.setText("CGST   9 % ");
        rightPanel.add(cgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 415, 150, 20));

        total.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        total.setText("Total");
        rightPanel.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 500, 150, 20));
        rightPanel.add(txt_remarks, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 588, 360, 34));

        remarks.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        remarks.setText("Remarks:");
        rightPanel.add(remarks, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 595, 125, 20));

        totalInWords1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        totalInWords1.setText("Total in words:");
        rightPanel.add(totalInWords1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 555, 125, 20));

        btn_print.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn_print.setText("Print");
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });
        rightPanel.add(btn_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 580, 90, 30));

        sgst.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        sgst.setText("SGST   9 %");
        rightPanel.add(sgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 450, 150, 20));
        rightPanel.add(downSeparator, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 365, 796, 7));

        txt_total.setEditable(false);
        txt_total.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 495, 200, 30));

        txt_amount.setEditable(false);
        txt_amount.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 375, 200, 30));

        txt_cgst.setEditable(false);
        txt_cgst.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_cgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 410, 200, 30));

        txt_sgst.setEditable(false);
        txt_sgst.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_sgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 445, 200, 30));

        txt_totalInWords.setEditable(false);
        txt_totalInWords.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_totalInWords, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 548, 360, 34));

        txt_yearTo.setEditable(false);
        txt_yearTo.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_yearTo, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 265, 100, 30));

        txt_yearFrom.setEditable(false);
        txt_yearFrom.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_yearFrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 265, 100, 30));

        txt_date.setEditable(false);
        txt_date.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 20, 120, 30));

        txt_gstin.setEditable(false);
        txt_gstin.setText("23KFEES0");
        txt_gstin.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_gstin, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 55, 120, 30));

        txt_receiptNo.setEditable(false);
        txt_receiptNo.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        rightPanel.add(txt_receiptNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 200, 30));

        paymentModeSelect.setEditable(false);
        paymentModeSelect.setBackground(new java.awt.Color(0, 153, 153));
        paymentModeSelect.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        paymentModeSelect.setForeground(new java.awt.Color(102, 51, 0));
        paymentModeSelect.setText("Select Payment Mode");
        paymentModeSelect.setBorder(null);
        rightPanel.add(paymentModeSelect, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 60, 140, 20));

        bankNameSelect.setEditable(false);
        bankNameSelect.setBackground(new java.awt.Color(0, 153, 153));
        bankNameSelect.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        bankNameSelect.setForeground(new java.awt.Color(102, 51, 0));
        bankNameSelect.setText("Select Bank Name");
        bankNameSelect.setBorder(null);
        rightPanel.add(bankNameSelect, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 130, 140, 20));

        ddNoEnter.setEditable(false);
        ddNoEnter.setBackground(new java.awt.Color(0, 153, 153));
        ddNoEnter.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        ddNoEnter.setForeground(new java.awt.Color(102, 51, 0));
        ddNoEnter.setText("Enter DD No");
        ddNoEnter.setBorder(null);
        rightPanel.add(ddNoEnter, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 95, 140, 20));

        registrationNoSelect.setEditable(false);
        registrationNoSelect.setBackground(new java.awt.Color(0, 153, 153));
        registrationNoSelect.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        registrationNoSelect.setForeground(new java.awt.Color(102, 51, 0));
        registrationNoSelect.setText("Select Registration No");
        registrationNoSelect.setBorder(null);
        rightPanel.add(registrationNoSelect, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 165, 140, 20));

        chequeNoEnter.setEditable(false);
        chequeNoEnter.setBackground(new java.awt.Color(0, 153, 153));
        chequeNoEnter.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        chequeNoEnter.setForeground(new java.awt.Color(102, 51, 0));
        chequeNoEnter.setText("Enter Cheque No");
        chequeNoEnter.setBorder(null);
        rightPanel.add(chequeNoEnter, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 95, 140, 20));

        mainAddFeesPanel.add(rightPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 2, 896, 646));

        noDueFeesPanel.setBackground(new java.awt.Color(0, 153, 153));
        noDueFeesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        noDueFees.setBackground(new java.awt.Color(0, 153, 153));
        noDueFees.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        noDueFees.setText("No Due Fees");
        noDueFeesPanel.add(noDueFees, new org.netbeans.lib.awtextra.AbsoluteConstraints(338, 298, 220, 50));

        exitButtonDue.setBackground(new java.awt.Color(0, 153, 153));
        exitButtonDue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonDueMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonDueMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonDueMouseExited(evt);
            }
        });

        ExitButtonLabel1.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel1.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel1.setText("X");

        javax.swing.GroupLayout exitButtonDueLayout = new javax.swing.GroupLayout(exitButtonDue);
        exitButtonDue.setLayout(exitButtonDueLayout);
        exitButtonDueLayout.setHorizontalGroup(
            exitButtonDueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonDueLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonDueLayout.setVerticalGroup(
            exitButtonDueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonDueLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        noDueFeesPanel.add(exitButtonDue, new org.netbeans.lib.awtextra.AbsoluteConstraints(838, 0, 60, -1));

        mainAddFeesPanel.add(noDueFeesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 2, 896, 646));

        getContentPane().add(mainAddFeesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseEntered
        Color clr=new Color(0,153,153);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseEntered

    private void homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseExited
        Color clr=new Color(0,102,102);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseExited

    private void searchRecordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseEntered
        Color clr=new Color(0,153,153);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseEntered

    private void searchRecordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseExited
        Color clr=new Color(0,102,102);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseExited

    private void editCourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseEntered
        Color clr=new Color(0,153,153);
        editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseEntered

    private void editCourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseExited
          Color clr=new Color(0,102,102);
          editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseExited

    private void courseListMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseEntered
          Color clr=new Color(0,153,153);
          courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseEntered

    private void courseListMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseExited
          Color clr=new Color(0,102,102);
          courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseExited

    private void viewReportMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseEntered
          Color clr=new Color(0,153,153);
          viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseEntered

    private void viewReportMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseExited
          Color clr=new Color(0,102,102);
          viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseExited

    private void LogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseEntered
          Color clr=new Color(0,153,153);
          Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseEntered

    private void LogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseExited
          Color clr=new Color(0,102,102);
          Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseExited

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
            System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
        if(validation()==true)
        {
            if(insertData()==true)
            {    
              JOptionPane.showMessageDialog(this,"record inserted successfully");
              PrintReceipt print=new PrintReceipt();
              print.show();
              this.dispose();
            }  
            else
            JOptionPane.showMessageDialog(this,"record insertion failed");    
        }
        else
            JOptionPane.showMessageDialog(this,"Please fill all the Fields");    
    }//GEN-LAST:event_btn_printActionPerformed

    private void txt_paymentModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_paymentModeActionPerformed
         if(txt_paymentMode.getSelectedIndex()==0)
        {    
            ddNo.setVisible(true);
            txt_ddNo.setVisible(true);
            ddNoEnter.setVisible(true);
            chequeNo.setVisible(false);
            txt_chequeNo.setVisible(false);
            chequeNoEnter.setVisible(false);
            bankName.setVisible(true);
            txt_bankName.setVisible(true);
            bankNameSelect.setVisible(true);
        }   
         if(txt_paymentMode.getSelectedIndex()==1)
        {    
            ddNo.setVisible(false);
            txt_ddNo.setVisible(false);
            ddNoEnter.setVisible(false);
            chequeNo.setVisible(true);
            txt_chequeNo.setVisible(true);
            chequeNoEnter.setVisible(true);
            bankName.setVisible(true);
            txt_bankName.setVisible(true);
            bankNameSelect.setVisible(true);
        }  
         if(txt_paymentMode.getSelectedIndex()==2)
        {    
            ddNo.setVisible(false);
            txt_ddNo.setVisible(false);
            ddNoEnter.setVisible(false);
            chequeNo.setVisible(false);
            txt_chequeNo.setVisible(false);
            chequeNoEnter.setVisible(false);
            bankName.setVisible(false);
            txt_bankName.setVisible(false);
            bankNameSelect.setVisible(false);
        }   
         if(txt_paymentMode.getSelectedIndex()==3)
        {    
            ddNo.setVisible(false);
            txt_ddNo.setVisible(false);
            chequeNo.setVisible(false);
            txt_chequeNo.setVisible(false);
            bankName.setVisible(true);
            txt_bankName.setVisible(true);
            bankNameSelect.setVisible(true);
        }   
    }//GEN-LAST:event_txt_paymentModeActionPerformed

    private void txt_registrationNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_registrationNoActionPerformed
             studentNameCourseNameAmount();
    }//GEN-LAST:event_txt_registrationNoActionPerformed

    private void exitButtonDueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonDueMouseClicked
             System.exit(0);
    }//GEN-LAST:event_exitButtonDueMouseClicked

    private void exitButtonDueMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonDueMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButtonDue.setBackground(mouseEnterColor);

    }//GEN-LAST:event_exitButtonDueMouseEntered

    private void exitButtonDueMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonDueMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButtonDue.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonDueMouseExited

    private void leftPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_leftPanelMouseClicked
        LoginPage login = new LoginPage();
        login.show();
        this.dispose();
    }//GEN-LAST:event_leftPanelMouseClicked

    private void viewReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseClicked
        ViewReport report= new ViewReport();
       report.show();
       this.dispose();
    }//GEN-LAST:event_viewReportMouseClicked

    private void courseListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseClicked
        ViewCourse view = new ViewCourse();
        view.show();
        this.dispose();
    }//GEN-LAST:event_courseListMouseClicked

    private void editCourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseClicked
        EditCourse edit=new EditCourse();
        edit.show();
        this.dispose();
    }//GEN-LAST:event_editCourseMouseClicked

    private void searchRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseClicked
       SearchRecord search=new SearchRecord();
       search.show();
       this.dispose();
    }//GEN-LAST:event_searchRecordMouseClicked

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        HomePage home=new HomePage();
        home.show();
        this.dispose();
    }//GEN-LAST:event_homeMouseClicked

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
         LoginPage login = new LoginPage();
        login.show();
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddFees().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JLabel ExitButtonLabel1;
    private javax.swing.JPanel Logout;
    private javax.swing.JLabel ReceiptNoUiet;
    private javax.swing.JLabel amountRs;
    private javax.swing.JLabel bankName;
    private javax.swing.JTextField bankNameSelect;
    private javax.swing.JButton btn_print;
    private javax.swing.JLabel cgst;
    private javax.swing.JLabel chequeNo;
    private javax.swing.JTextField chequeNoEnter;
    private javax.swing.JLabel course;
    private javax.swing.JLabel courseFee;
    private javax.swing.JPanel courseList;
    private javax.swing.JLabel courseListLabel;
    private javax.swing.JLabel date;
    private javax.swing.JLabel ddNo;
    private javax.swing.JTextField ddNoEnter;
    private javax.swing.JSeparator downSeparator;
    private javax.swing.JPanel editCourse;
    private javax.swing.JLabel editCourseLabel;
    private javax.swing.JPanel exitButton;
    private javax.swing.JPanel exitButtonDue;
    private javax.swing.JLabel gstin;
    private javax.swing.JLabel heads;
    private javax.swing.JPanel home;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JPanel mainAddFeesPanel;
    private javax.swing.JLabel modeOfPayment;
    private javax.swing.JLabel noDueFees;
    private javax.swing.JPanel noDueFeesPanel;
    private javax.swing.JTextField paymentModeSelect;
    private javax.swing.JTextField registrationNoSelect;
    private javax.swing.JLabel remarks;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JLabel rollNo;
    private javax.swing.JPanel searchRecord;
    private javax.swing.JLabel searchRecordLabel;
    private javax.swing.JLabel sgst;
    private javax.swing.JLabel studentName;
    private javax.swing.JLabel thePaymentYear;
    private javax.swing.JLabel to;
    private javax.swing.JLabel total;
    private javax.swing.JLabel totalInWords1;
    private javax.swing.JSeparator totalSeparator;
    private javax.swing.JTextField txt_amount;
    private javax.swing.JComboBox<String> txt_bankName;
    private javax.swing.JTextField txt_cgst;
    private app.bolivia.swing.JCTextField txt_chequeNo;
    private app.bolivia.swing.JCTextField txt_courseName;
    private javax.swing.JTextField txt_date;
    private app.bolivia.swing.JCTextField txt_ddNo;
    private javax.swing.JTextField txt_gstin;
    private javax.swing.JComboBox<String> txt_paymentMode;
    private javax.swing.JTextField txt_receiptNo;
    private javax.swing.JComboBox<String> txt_registrationNo;
    private app.bolivia.swing.JCTextField txt_remarks;
    private javax.swing.JTextField txt_sgst;
    private app.bolivia.swing.JCTextField txt_studentName;
    private javax.swing.JTextField txt_total;
    private app.bolivia.swing.JCTextField txt_totalInWords;
    private javax.swing.JTextField txt_yearFrom;
    private javax.swing.JTextField txt_yearTo;
    private javax.swing.JSeparator upSeparator;
    private javax.swing.JPanel viewReport;
    private javax.swing.JLabel viewReportLabel;
    // End of variables declaration//GEN-END:variables
}
