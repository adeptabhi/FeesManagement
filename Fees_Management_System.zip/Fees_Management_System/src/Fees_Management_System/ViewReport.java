
package Fees_Management_System;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.Year;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ViewReport extends javax.swing.JFrame {

    DefaultTableModel model;
    String courseIdMain;
    public ViewReport() {
        initComponents();
        courseFill();
        setDate();
        setRecordToTable();
    } 
    public Date setDate()
    {
         SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
         Date date = new Date();
         Date nextdate  = Date.from(Instant.now().plusSeconds(0)); 
         txt_fromDate.setDate(nextdate);
         txt_toDate.setDate(nextdate);
         return nextdate;
    }
    void courseFill()
    {
         txt_courseName.addItem("ALL");        
         try
            {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst= con.prepareStatement("select courseName from course");
              ResultSet rs=pst.executeQuery();
              while(rs.next())
              {
                  txt_courseName.addItem(rs.getString("courseName"));
              }
            } 
           catch(Exception e)
            {
                e.printStackTrace();
            }
    } 
     public void setRecordToTable()
   {
       String courseName = txt_courseName.getSelectedItem().toString();
       SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
       String fromDate = formatter.format(txt_fromDate.getDate());
       String toDate = formatter.format(txt_toDate.getDate());
       Float total=0.0f;
       if(courseName.equals("ALL")==true)
       {
         try
        {
            Connection con =DBConnection.getConnection();
            PreparedStatement pst=con.prepareStatement("select id,registrationNo,studentName,courseName,amount,date,paymentMode from feesDetails where date>=? and date<=?");
            pst.setString(1, fromDate);
            pst.setString(2, toDate);
            ResultSet rs=pst.executeQuery();
            while(rs.next())
            {
                String receiptNo ="UIETFR-"+rs.getString("id");
                String registrationNo="UIETRS-"+rs.getString("registrationNo");
                String studentName=rs.getString("studentName");
                String courseName1=rs.getString("courseName");
                String amount=rs.getString("amount");
                String date=rs.getString("date");
                String paymentMode=rs.getString("paymentMode");
                total+=rs.getFloat("amount");
                Object[] obj ={receiptNo,registrationNo,studentName,courseName1,amount,date,paymentMode};
                model = (DefaultTableModel)tbl_report.getModel();
                model.addRow(obj); 
            }
        }
         catch(Exception e)
        {
            e.printStackTrace();
        }  
       }    
       else
       {  
        try
        {
            Connection con =DBConnection.getConnection();
            PreparedStatement pst=con.prepareStatement("select id,registrationNo,studentName,courseName,amount,date,paymentMode from feesDetails where date>=? and date<=? and courseName=?");
            pst.setString(1, fromDate);
            pst.setString(2, toDate);
            pst.setString(3, courseName);
            ResultSet rs=pst.executeQuery();
            while(rs.next())
            {
                String receiptNo ="UIETFR-"+rs.getString("id");
                String registrationNo="UIETRS-"+rs.getString("registrationNo");
                String studentName=rs.getString("studentName");
                String courseName1=rs.getString("courseName");
                String amount=rs.getString("amount");
                String date=rs.getString("date");
                String paymentMode=rs.getString("paymentMode");
                total+=rs.getFloat("amount");
                Object[] obj ={receiptNo,registrationNo,studentName,courseName1,amount,date,paymentMode};
                model = (DefaultTableModel)tbl_report.getModel();
                model.addRow(obj); 
            }
        }
         catch(Exception e)
        {
            e.printStackTrace();
        } 
       } 
       txt_courseSelected.setText(courseName);
       txt_totalAmountCollected.setText(Float.toString(total));
   }
      public void clearTable()
        {
            DefaultTableModel model = (DefaultTableModel) tbl_report.getModel();
            model.setRowCount(0);
        }
      public void exportToExcel()
      {
          XSSFWorkbook wb = new XSSFWorkbook();
          XSSFSheet ws = wb.createSheet();
          TreeMap<String,Object[]> map = new TreeMap<>();
          map.put("0",new Object[]{model.getColumnName(0),model.getColumnName(1),model.getColumnName(2),model.getColumnName(3),model.getColumnName(4),model.getColumnName(5),model.getColumnName(6)});
          for(int i=0;i<model.getRowCount();i++)
          {    
              map.put(Integer.toString(i),new Object[]{model.getValueAt(i, 0),model.getValueAt(i, 1),model.getValueAt(i, 2),model.getValueAt(i, 3),model.getValueAt(i, 4),model.getValueAt(i, 5),model.getValueAt(i, 6)});
              
          }
          Set<String> id=map.keySet();
          XSSFRow fRow;
          int rowId = 0;
          for(String key :id)
          {
              fRow = ws.createRow(rowId++);
              Object[] value = map.get(key);
              int cellId = 0;
              for(Object object : value)
              {
                  XSSFCell cell= fRow.createCell(cellId++);
                  cell.setCellValue(object.toString());
              }
          } 
          try
          {
           FileOutputStream fos=new FileOutputStream(new File(txt_filePath.getText()));
           wb.write(fos);
           JOptionPane.showMessageDialog(this,"File exported successfully"+txt_filePath.getText());
          }
          catch(Exception e)
          {
              e.printStackTrace();
          }
      }        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainAddFeesPanel = new javax.swing.JPanel();
        leftPanel = new javax.swing.JPanel();
        leftPanel1 = new javax.swing.JPanel();
        home = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        searchRecord = new javax.swing.JPanel();
        searchRecordLabel = new javax.swing.JLabel();
        editCourse = new javax.swing.JPanel();
        editCourseLabel = new javax.swing.JLabel();
        courseList = new javax.swing.JPanel();
        courseListLabel = new javax.swing.JLabel();
        Logout = new javax.swing.JPanel();
        logoutLabel = new javax.swing.JLabel();
        addFees = new javax.swing.JPanel();
        addFeesLabel = new javax.swing.JLabel();
        rightPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        serchRecord = new javax.swing.JLabel();
        separator3 = new javax.swing.JSeparator();
        toDateLabel = new javax.swing.JLabel();
        txt_courseName = new javax.swing.JComboBox<>();
        selectCourseLabel = new javax.swing.JLabel();
        selectDateLabel = new javax.swing.JLabel();
        fromDateLabel = new javax.swing.JLabel();
        txt_toDate = new com.toedter.calendar.JDateChooser();
        txt_fromDate = new com.toedter.calendar.JDateChooser();
        btn_submit = new javax.swing.JButton();
        btn_exportToExcel = new javax.swing.JButton();
        btn_print = new javax.swing.JButton();
        btn_browse = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_report = new javax.swing.JTable();
        txt_filePath = new javax.swing.JTextField();
        detailsPanel = new javax.swing.JPanel();
        totalAmountCollected = new javax.swing.JLabel();
        courseSelected = new javax.swing.JLabel();
        txt_courseSelected = new javax.swing.JLabel();
        txt_totalAmountCollected = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("AddFeesFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainAddFeesPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainAddFeesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        leftPanel.setBackground(new java.awt.Color(0, 102, 102));
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        leftPanel1.setBackground(new java.awt.Color(0, 102, 102));
        leftPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                leftPanel1MouseClicked(evt);
            }
        });
        leftPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        home.setBackground(new java.awt.Color(0, 102, 102));
        home.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                homeMouseExited(evt);
            }
        });

        homeLabel.setBackground(new java.awt.Color(0, 102, 102));
        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        homeLabel.setForeground(new java.awt.Color(255, 255, 255));
        homeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Home.png"))); // NOI18N
        homeLabel.setText("Home");

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(homeLabel)
                .addContainerGap(89, Short.MAX_VALUE))
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homeLayout.createSequentialGroup()
                .addComponent(homeLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel1.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 205, 54));

        searchRecord.setBackground(new java.awt.Color(0, 102, 102));
        searchRecord.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchRecordMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                searchRecordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                searchRecordMouseExited(evt);
            }
        });

        searchRecordLabel.setBackground(new java.awt.Color(0, 102, 102));
        searchRecordLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchRecordLabel.setForeground(new java.awt.Color(255, 255, 255));
        searchRecordLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/SearchRecord.png"))); // NOI18N
        searchRecordLabel.setText("Search Record");

        javax.swing.GroupLayout searchRecordLayout = new javax.swing.GroupLayout(searchRecord);
        searchRecord.setLayout(searchRecordLayout);
        searchRecordLayout.setHorizontalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchRecordLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchRecordLabel)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        searchRecordLayout.setVerticalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, searchRecordLayout.createSequentialGroup()
                .addComponent(searchRecordLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel1.add(searchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 144, 205, 54));

        editCourse.setBackground(new java.awt.Color(0, 102, 102));
        editCourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editCourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                editCourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                editCourseMouseExited(evt);
            }
        });

        editCourseLabel.setBackground(new java.awt.Color(0, 102, 102));
        editCourseLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        editCourseLabel.setForeground(new java.awt.Color(255, 255, 255));
        editCourseLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/EditCourse.png"))); // NOI18N
        editCourseLabel.setText("Edit Course");

        javax.swing.GroupLayout editCourseLayout = new javax.swing.GroupLayout(editCourse);
        editCourse.setLayout(editCourseLayout);
        editCourseLayout.setHorizontalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editCourseLabel)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        editCourseLayout.setVerticalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editCourseLayout.createSequentialGroup()
                .addComponent(editCourseLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel1.add(editCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 228, 205, 54));

        courseList.setBackground(new java.awt.Color(0, 102, 102));
        courseList.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        courseList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                courseListMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                courseListMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                courseListMouseExited(evt);
            }
        });

        courseListLabel.setBackground(new java.awt.Color(0, 102, 102));
        courseListLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        courseListLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseListLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/CourseList.png"))); // NOI18N
        courseListLabel.setText("Course List");

        javax.swing.GroupLayout courseListLayout = new javax.swing.GroupLayout(courseList);
        courseList.setLayout(courseListLayout);
        courseListLayout.setHorizontalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(courseListLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(courseListLabel)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        courseListLayout.setVerticalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, courseListLayout.createSequentialGroup()
                .addComponent(courseListLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel1.add(courseList, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 312, 205, 54));

        Logout.setBackground(new java.awt.Color(0, 102, 102));
        Logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                LogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                LogoutMouseExited(evt);
            }
        });

        logoutLabel.setBackground(new java.awt.Color(0, 102, 102));
        logoutLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Logout.png"))); // NOI18N
        logoutLabel.setText("Logout");

        javax.swing.GroupLayout LogoutLayout = new javax.swing.GroupLayout(Logout);
        Logout.setLayout(LogoutLayout);
        LogoutLayout.setHorizontalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LogoutLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoutLabel)
                .addContainerGap(85, Short.MAX_VALUE))
        );
        LogoutLayout.setVerticalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LogoutLayout.createSequentialGroup()
                .addComponent(logoutLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel1.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 480, 210, 54));

        addFees.setBackground(new java.awt.Color(0, 102, 102));
        addFees.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addFees.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addFeesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addFeesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addFeesMouseExited(evt);
            }
        });

        addFeesLabel.setBackground(new java.awt.Color(0, 102, 102));
        addFeesLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        addFeesLabel.setForeground(new java.awt.Color(255, 255, 255));
        addFeesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/AddFees.png"))); // NOI18N
        addFeesLabel.setText("Add Fees");

        javax.swing.GroupLayout addFeesLayout = new javax.swing.GroupLayout(addFees);
        addFees.setLayout(addFeesLayout);
        addFeesLayout.setHorizontalGroup(
            addFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addFeesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(addFeesLabel)
                .addContainerGap(64, Short.MAX_VALUE))
        );
        addFeesLayout.setVerticalGroup(
            addFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addFeesLayout.createSequentialGroup()
                .addComponent(addFeesLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel1.add(addFees, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 396, 205, 54));

        leftPanel.add(leftPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 350, 646));

        mainAddFeesPanel.add(leftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 350, 646));

        rightPanel.setBackground(new java.awt.Color(0, 153, 153));
        rightPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        rightPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(838, 0, 60, -1));

        serchRecord.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        serchRecord.setForeground(new java.awt.Color(255, 255, 255));
        serchRecord.setText("Report");
        rightPanel.add(serchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 120, 40));

        separator3.setForeground(new java.awt.Color(0, 0, 0));
        rightPanel.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 896, 5));

        toDateLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        toDateLabel.setText("To Date:");
        rightPanel.add(toDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(395, 90, 60, 20));

        rightPanel.add(txt_courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 45, 200, 30));

        selectCourseLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        selectCourseLabel.setText("Select Course:");
        rightPanel.add(selectCourseLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 100, 20));

        selectDateLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        selectDateLabel.setText("Select Date:");
        rightPanel.add(selectDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 100, 20));

        fromDateLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fromDateLabel.setText("From Date:");
        rightPanel.add(fromDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 80, 20));

        txt_toDate.setMaxSelectableDate(setDate());
        rightPanel.add(txt_toDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(455, 85, 150, 30));

        txt_fromDate.setMaxSelectableDate(setDate());
        rightPanel.add(txt_fromDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 85, 150, 30));

        btn_submit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_submit.setText("Submit");
        btn_submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_submitActionPerformed(evt);
            }
        });
        rightPanel.add(btn_submit, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 125, 100, 30));

        btn_exportToExcel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_exportToExcel.setText("Export to Excel");
        btn_exportToExcel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exportToExcelActionPerformed(evt);
            }
        });
        rightPanel.add(btn_exportToExcel, new org.netbeans.lib.awtextra.AbsoluteConstraints(495, 160, -1, 30));

        btn_print.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_print.setText("Print");
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });
        rightPanel.add(btn_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 125, 100, 30));

        btn_browse.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_browse.setText("Browse");
        btn_browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_browseActionPerformed(evt);
            }
        });
        rightPanel.add(btn_browse, new org.netbeans.lib.awtextra.AbsoluteConstraints(395, 160, 90, 30));

        tbl_report.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Receipt No", "Registration No", "Student Name", "Course Name", "Amount", "Date", "Payment Mode"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbl_report);

        rightPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(52, 200, 830, 440));

        txt_filePath.setEditable(false);
        rightPanel.add(txt_filePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 330, 30));

        detailsPanel.setBackground(new java.awt.Color(0, 102, 102));
        detailsPanel.setForeground(new java.awt.Color(255, 255, 255));

        totalAmountCollected.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        totalAmountCollected.setForeground(new java.awt.Color(255, 255, 255));
        totalAmountCollected.setText("Total Amount Collected:");

        courseSelected.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        courseSelected.setForeground(new java.awt.Color(255, 255, 255));
        courseSelected.setText("Course Selected:");

        txt_courseSelected.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_courseSelected.setForeground(new java.awt.Color(255, 255, 255));

        txt_totalAmountCollected.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_totalAmountCollected.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout detailsPanelLayout = new javax.swing.GroupLayout(detailsPanel);
        detailsPanel.setLayout(detailsPanelLayout);
        detailsPanelLayout.setHorizontalGroup(
            detailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(detailsPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(detailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(courseSelected)
                    .addComponent(totalAmountCollected)
                    .addComponent(txt_courseSelected, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                    .addComponent(txt_totalAmountCollected, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        detailsPanelLayout.setVerticalGroup(
            detailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(detailsPanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(courseSelected, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_courseSelected, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalAmountCollected, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_totalAmountCollected, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                .addContainerGap())
        );

        rightPanel.add(detailsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 50, 252, 140));

        mainAddFeesPanel.add(rightPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 2, 896, 646));

        getContentPane().add(mainAddFeesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
  
    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void btn_submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_submitActionPerformed
        clearTable();
        setRecordToTable();
    }//GEN-LAST:event_btn_submitActionPerformed

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
       SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
       String fromDate = formatter.format(txt_fromDate.getDate());
       String toDate = formatter.format(txt_toDate.getDate());
       MessageFormat header = new MessageFormat("Report From "+fromDate+" To "+toDate);
       MessageFormat footer = new MessageFormat("page{0,number,integer}");
       try
       {
           tbl_report.print(JTable.PrintMode.FIT_WIDTH,header,footer);
       }
       catch(Exception e)
       {   
           e.getMessage();
       }    
    }//GEN-LAST:event_btn_printActionPerformed

    private void btn_browseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_browseActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.showOpenDialog(this);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
        String date = formatter.format(new Date());
        try
        {
            File f=fileChooser.getSelectedFile();
            String path =f.getAbsolutePath();
            path = path +"_"+date+".xlsx";
            txt_filePath.setText(path);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }   
    }//GEN-LAST:event_btn_browseActionPerformed

    private void btn_exportToExcelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exportToExcelActionPerformed
        if(txt_filePath.getText().length()==0)
        JOptionPane.showMessageDialog(this,"Please Select Path");
        else
        exportToExcel();
    }//GEN-LAST:event_btn_exportToExcelActionPerformed

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        HomePage home=new HomePage();
        home.show();
        this.dispose();
    }//GEN-LAST:event_homeMouseClicked

    private void homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseEntered
        Color clr=new Color(0,153,153);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseEntered

    private void homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseExited
        Color clr=new Color(0,102,102);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseExited

    private void searchRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseClicked
        SearchRecord search=new SearchRecord();
        search.show();
        this.dispose();
    }//GEN-LAST:event_searchRecordMouseClicked

    private void searchRecordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseEntered
        Color clr=new Color(0,153,153);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseEntered

    private void searchRecordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseExited
        Color clr=new Color(0,102,102);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseExited

    private void editCourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseClicked
        EditCourse edit=new EditCourse();
        edit.show();
        this.dispose();
    }//GEN-LAST:event_editCourseMouseClicked

    private void editCourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseEntered
        Color clr=new Color(0,153,153);
        editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseEntered

    private void editCourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseExited
        Color clr=new Color(0,102,102);
        editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseExited

    private void courseListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseClicked
        ViewCourse view = new ViewCourse();
        view.show();
        this.dispose();
    }//GEN-LAST:event_courseListMouseClicked

    private void courseListMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseEntered
        Color clr=new Color(0,153,153);
        courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseEntered

    private void courseListMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseExited
        Color clr=new Color(0,102,102);
        courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseExited

    private void leftPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_leftPanel1MouseClicked
        LoginPage login = new LoginPage();
        login.show();
        this.dispose();
    }//GEN-LAST:event_leftPanel1MouseClicked

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
        LoginPage login = new LoginPage();
        login.show();
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    private void LogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseEntered
        Color clr=new Color(0,153,153);
        Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseEntered

    private void LogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseExited
        Color clr=new Color(0,102,102);
        Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseExited

    private void addFeesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseClicked
        AddFees add= new AddFees();
        add.show();
        this.dispose();
    }//GEN-LAST:event_addFeesMouseClicked

    private void addFeesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseEntered
        Color clr=new Color(0,153,153);
        addFees.setBackground(clr);
    }//GEN-LAST:event_addFeesMouseEntered

    private void addFeesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseExited
        Color clr=new Color(0,102,102);
        addFees.setBackground(clr);
    }//GEN-LAST:event_addFeesMouseExited

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewReport.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
     

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewReport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JPanel Logout;
    private javax.swing.JPanel addFees;
    private javax.swing.JLabel addFeesLabel;
    private javax.swing.JButton btn_browse;
    private javax.swing.JButton btn_exportToExcel;
    private javax.swing.JButton btn_print;
    private javax.swing.JButton btn_submit;
    private javax.swing.JPanel courseList;
    private javax.swing.JLabel courseListLabel;
    private javax.swing.JLabel courseSelected;
    private javax.swing.JPanel detailsPanel;
    private javax.swing.JPanel editCourse;
    private javax.swing.JLabel editCourseLabel;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel fromDateLabel;
    private javax.swing.JPanel home;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel leftPanel1;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JPanel mainAddFeesPanel;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JPanel searchRecord;
    private javax.swing.JLabel searchRecordLabel;
    private javax.swing.JLabel selectCourseLabel;
    private javax.swing.JLabel selectDateLabel;
    private javax.swing.JSeparator separator3;
    private javax.swing.JLabel serchRecord;
    private javax.swing.JTable tbl_report;
    private javax.swing.JLabel toDateLabel;
    private javax.swing.JLabel totalAmountCollected;
    private javax.swing.JComboBox<String> txt_courseName;
    private javax.swing.JLabel txt_courseSelected;
    private javax.swing.JTextField txt_filePath;
    private com.toedter.calendar.JDateChooser txt_fromDate;
    private com.toedter.calendar.JDateChooser txt_toDate;
    private javax.swing.JLabel txt_totalAmountCollected;
    // End of variables declaration//GEN-END:variables
}
