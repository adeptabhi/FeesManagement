package Fees_Management_System;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import javax.swing.JOptionPane;
public class About extends javax.swing.JFrame {
    public About() {
        initComponents();
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainSignupPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        leftPanel = new javax.swing.JPanel();
        image = new javax.swing.JLabel();
        rightPanel = new javax.swing.JPanel();
        separator3 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btn_back = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(2, 2, 2, 2));
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("SignupPageFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainSignupPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainSignupPanel.setForeground(new java.awt.Color(51, 51, 51));
        mainSignupPanel.setMinimumSize(new java.awt.Dimension(1248, 648));
        mainSignupPanel.setPreferredSize(new java.awt.Dimension(1248, 648));
        mainSignupPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainSignupPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1188, 2, 60, -1));

        leftPanel.setBackground(new java.awt.Color(255, 255, 255));
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BgIcons/Copyright.png"))); // NOI18N
        leftPanel.add(image, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 648, 646));

        mainSignupPanel.add(leftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 648, 646));

        rightPanel.setBackground(new java.awt.Color(0, 153, 153));
        rightPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        separator3.setBackground(new java.awt.Color(0, 0, 0));
        separator3.setForeground(new java.awt.Color(0, 0, 0));
        rightPanel.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 598, 5));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyIcons/copyright.png"))); // NOI18N
        jLabel2.setText("2023, All rights reserved");
        rightPanel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(205, 40, 340, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CopyRight");
        rightPanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 120, -1));

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new java.awt.Color(0, 153, 153));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("No part of this software may reported, in whole or in parts without\nthe specific written permission of the owner. The Software is\ndeveloped by Mr. Vikas Yadav\n\n                                                                                                Thank You");
        jTextArea1.setBorder(null);
        jScrollPane1.setViewportView(jTextArea1);

        rightPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 540, 140));

        btn_back.setBackground(new java.awt.Color(0, 102, 102));
        btn_back.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn_back.setForeground(new java.awt.Color(255, 255, 255));
        btn_back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyIcons/back1.png"))); // NOI18N
        btn_back.setText("Back");
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });
        rightPanel.add(btn_back, new org.netbeans.lib.awtextra.AbsoluteConstraints(468, 608, 130, 40));

        mainSignupPanel.add(rightPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 2, 598, 646));

        getContentPane().add(mainSignupPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));
        mainSignupPanel.getAccessibleContext().setAccessibleName("");
        mainSignupPanel.getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        HomePage home = new HomePage();
          home.show();
          this.dispose();
    }//GEN-LAST:event_btn_backActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(About.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(About.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(About.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(About.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new About().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JButton btn_back;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel image;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel mainSignupPanel;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JSeparator separator3;
    // End of variables declaration//GEN-END:variables

}
