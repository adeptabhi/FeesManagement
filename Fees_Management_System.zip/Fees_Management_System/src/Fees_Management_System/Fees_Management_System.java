package Fees_Management_System;
public class Fees_Management_System {
    public static void main(String[] args) {
    }
    
}
