
package Fees_Management_System;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.Year;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class SearchRecord extends javax.swing.JFrame {

    DefaultTableModel model;
    public SearchRecord() {
        initComponents();
        setRecordToTable();
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainAddFeesPanel = new javax.swing.JPanel();
        leftPanel = new javax.swing.JPanel();
        Logout = new javax.swing.JPanel();
        logoutLabel = new javax.swing.JLabel();
        viewReport = new javax.swing.JPanel();
        viewReportLabel = new javax.swing.JLabel();
        courseList = new javax.swing.JPanel();
        courseListLabel = new javax.swing.JLabel();
        editCourse = new javax.swing.JPanel();
        editCourseLabel = new javax.swing.JLabel();
        addFees = new javax.swing.JPanel();
        addFeesLabel = new javax.swing.JLabel();
        home = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        rightPanel = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_studentData = new javax.swing.JTable();
        serchRecord = new javax.swing.JLabel();
        enterSearchString = new javax.swing.JLabel();
        separator3 = new javax.swing.JSeparator();
        txt_enterSearchString = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("AddFeesFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainAddFeesPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainAddFeesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        leftPanel.setBackground(new java.awt.Color(0, 102, 102));
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Logout.setBackground(new java.awt.Color(0, 102, 102));
        Logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                LogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                LogoutMouseExited(evt);
            }
        });

        logoutLabel.setBackground(new java.awt.Color(0, 102, 102));
        logoutLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Logout.png"))); // NOI18N
        logoutLabel.setText("Logout");

        javax.swing.GroupLayout LogoutLayout = new javax.swing.GroupLayout(Logout);
        Logout.setLayout(LogoutLayout);
        LogoutLayout.setHorizontalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LogoutLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoutLabel)
                .addContainerGap(85, Short.MAX_VALUE))
        );
        LogoutLayout.setVerticalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LogoutLayout.createSequentialGroup()
                .addComponent(logoutLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 480, 210, 54));

        viewReport.setBackground(new java.awt.Color(0, 102, 102));
        viewReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewReportMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewReportMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewReportMouseExited(evt);
            }
        });

        viewReportLabel.setBackground(new java.awt.Color(0, 102, 102));
        viewReportLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        viewReportLabel.setForeground(new java.awt.Color(255, 255, 255));
        viewReportLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/ViewAllRecord.png"))); // NOI18N
        viewReportLabel.setText("View Report");

        javax.swing.GroupLayout viewReportLayout = new javax.swing.GroupLayout(viewReport);
        viewReport.setLayout(viewReportLayout);
        viewReportLayout.setHorizontalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewReportLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(viewReportLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        viewReportLayout.setVerticalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewReportLayout.createSequentialGroup()
                .addComponent(viewReportLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(viewReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 396, 205, 54));

        courseList.setBackground(new java.awt.Color(0, 102, 102));
        courseList.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        courseList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                courseListMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                courseListMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                courseListMouseExited(evt);
            }
        });

        courseListLabel.setBackground(new java.awt.Color(0, 102, 102));
        courseListLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        courseListLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseListLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/CourseList.png"))); // NOI18N
        courseListLabel.setText("Course List");

        javax.swing.GroupLayout courseListLayout = new javax.swing.GroupLayout(courseList);
        courseList.setLayout(courseListLayout);
        courseListLayout.setHorizontalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(courseListLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(courseListLabel)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        courseListLayout.setVerticalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, courseListLayout.createSequentialGroup()
                .addComponent(courseListLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(courseList, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 312, 205, 54));

        editCourse.setBackground(new java.awt.Color(0, 102, 102));
        editCourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editCourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                editCourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                editCourseMouseExited(evt);
            }
        });

        editCourseLabel.setBackground(new java.awt.Color(0, 102, 102));
        editCourseLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        editCourseLabel.setForeground(new java.awt.Color(255, 255, 255));
        editCourseLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/EditCourse.png"))); // NOI18N
        editCourseLabel.setText("Edit Course");

        javax.swing.GroupLayout editCourseLayout = new javax.swing.GroupLayout(editCourse);
        editCourse.setLayout(editCourseLayout);
        editCourseLayout.setHorizontalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editCourseLabel)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        editCourseLayout.setVerticalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editCourseLayout.createSequentialGroup()
                .addComponent(editCourseLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(editCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 228, 205, 54));

        addFees.setBackground(new java.awt.Color(0, 102, 102));
        addFees.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addFees.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addFeesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addFeesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addFeesMouseExited(evt);
            }
        });

        addFeesLabel.setBackground(new java.awt.Color(0, 102, 102));
        addFeesLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        addFeesLabel.setForeground(new java.awt.Color(255, 255, 255));
        addFeesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/AddFees.png"))); // NOI18N
        addFeesLabel.setText("Add Fees");

        javax.swing.GroupLayout addFeesLayout = new javax.swing.GroupLayout(addFees);
        addFees.setLayout(addFeesLayout);
        addFeesLayout.setHorizontalGroup(
            addFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addFeesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(addFeesLabel)
                .addContainerGap(64, Short.MAX_VALUE))
        );
        addFeesLayout.setVerticalGroup(
            addFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addFeesLayout.createSequentialGroup()
                .addComponent(addFeesLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(addFees, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 144, 205, 54));

        home.setBackground(new java.awt.Color(0, 102, 102));
        home.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                homeMouseExited(evt);
            }
        });

        homeLabel.setBackground(new java.awt.Color(0, 102, 102));
        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        homeLabel.setForeground(new java.awt.Color(255, 255, 255));
        homeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Home.png"))); // NOI18N
        homeLabel.setText("Home");

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(homeLabel)
                .addContainerGap(89, Short.MAX_VALUE))
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homeLayout.createSequentialGroup()
                .addComponent(homeLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 205, 54));

        mainAddFeesPanel.add(leftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 350, 646));

        rightPanel.setBackground(new java.awt.Color(0, 153, 153));
        rightPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        rightPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(838, 0, 60, -1));

        tbl_studentData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Registration No", "Student Name", "Course Name", "Course Price", "Receipt No", "Fees Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbl_studentData);
        if (tbl_studentData.getColumnModel().getColumnCount() > 0) {
            tbl_studentData.getColumnModel().getColumn(5).setResizable(false);
        }

        rightPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 860, 500));

        serchRecord.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        serchRecord.setForeground(new java.awt.Color(255, 255, 255));
        serchRecord.setText("Search Record");
        rightPanel.add(serchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(328, 0, 240, 40));

        enterSearchString.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        enterSearchString.setForeground(new java.awt.Color(255, 255, 255));
        enterSearchString.setText("Enter Search String :");
        rightPanel.add(enterSearchString, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 250, 40));

        separator3.setForeground(new java.awt.Color(255, 255, 255));
        rightPanel.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(306, 40, 280, 5));

        txt_enterSearchString.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_enterSearchString.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_enterSearchStringActionPerformed(evt);
            }
        });
        txt_enterSearchString.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_enterSearchStringKeyReleased(evt);
            }
        });
        rightPanel.add(txt_enterSearchString, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 92, 330, 36));

        mainAddFeesPanel.add(rightPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 2, 896, 646));

        getContentPane().add(mainAddFeesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
   public void setRecordToTable()
   {
       String registrationNo,receiptNo,studentName,status,courseName,coursePrice;
        try
        {
            Connection con =DBConnection.getConnection();
            PreparedStatement pst=con.prepareStatement("select * from studentDetails");
            ResultSet rsStd=pst.executeQuery();
            while(rsStd.next())
            {
                registrationNo = "UIETRS-"+rsStd.getString("id");
                PreparedStatement pst1= con.prepareStatement("select id from feesDetails where registrationNo=?");
                   pst1.setInt(1,rsStd.getInt("id"));
                   ResultSet rsFee=pst1.executeQuery();
                   if(rsFee.next())
                   {    
                     receiptNo="UIETFR-"+rsFee.getString("id");
                     status="Paid";
                   }  
                   else
                   {    
                     receiptNo="- - - - - - - -";
                     status="Due";
                   }  
                studentName=rsStd.getString("firstName")+" "+rsStd.getString("lastName");
                courseName=rsStd.getString("courseName");
                coursePrice=rsStd.getString("coursePrice");
                Object[] obj ={registrationNo,studentName,courseName,coursePrice,receiptNo,status};
                model = (DefaultTableModel)tbl_studentData.getModel();
                model.addRow(obj);

            }
        }
         catch(Exception e)
        {
            e.printStackTrace();
        }  
   }
   public void search(String str)
   {
       model = (DefaultTableModel) tbl_studentData.getModel();
       TableRowSorter<DefaultTableModel> trs = new TableRowSorter<> (model);
       tbl_studentData.setRowSorter(trs);
       trs.setRowFilter(RowFilter.regexFilter(str));
   }
    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void txt_enterSearchStringActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_enterSearchStringActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_enterSearchStringActionPerformed

    private void txt_enterSearchStringKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_enterSearchStringKeyReleased
       String searchString = txt_enterSearchString.getText();
       search(searchString);
    }//GEN-LAST:event_txt_enterSearchStringKeyReleased

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
        LoginPage login = new LoginPage();
        login.show();
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    private void LogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseEntered
        Color clr=new Color(0,153,153);
        Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseEntered

    private void LogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseExited
        Color clr=new Color(0,102,102);
        Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseExited

    private void viewReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseClicked
        ViewReport report= new ViewReport();
        report.show();
        this.dispose();
    }//GEN-LAST:event_viewReportMouseClicked

    private void viewReportMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseEntered
        Color clr=new Color(0,153,153);
        viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseEntered

    private void viewReportMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseExited
        Color clr=new Color(0,102,102);
        viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseExited

    private void courseListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseClicked
        ViewCourse view = new ViewCourse();
        view.show();
        this.dispose();
    }//GEN-LAST:event_courseListMouseClicked

    private void courseListMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseEntered
        Color clr=new Color(0,153,153);
        courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseEntered

    private void courseListMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseExited
        Color clr=new Color(0,102,102);
        courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseExited

    private void editCourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseClicked
        EditCourse edit=new EditCourse();
        edit.show();
        this.dispose();
    }//GEN-LAST:event_editCourseMouseClicked

    private void editCourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseEntered
        Color clr=new Color(0,153,153);
        editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseEntered

    private void editCourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseExited
        Color clr=new Color(0,102,102);
        editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseExited

    private void addFeesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseClicked
        AddFees add= new AddFees();
        add.show();
        this.dispose();
    }//GEN-LAST:event_addFeesMouseClicked

    private void addFeesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseEntered
        Color clr=new Color(0,153,153);
        addFees.setBackground(clr);
    }//GEN-LAST:event_addFeesMouseEntered

    private void addFeesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addFeesMouseExited
        Color clr=new Color(0,102,102);
        addFees.setBackground(clr);
    }//GEN-LAST:event_addFeesMouseExited

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        HomePage home=new HomePage();
        home.show();
        this.dispose();
    }//GEN-LAST:event_homeMouseClicked

    private void homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseEntered
        Color clr=new Color(0,153,153);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseEntered

    private void homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseExited
        Color clr=new Color(0,102,102);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseExited

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SearchRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SearchRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SearchRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SearchRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
     

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SearchRecord().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JPanel Logout;
    private javax.swing.JPanel addFees;
    private javax.swing.JLabel addFeesLabel;
    private javax.swing.JPanel courseList;
    private javax.swing.JLabel courseListLabel;
    private javax.swing.JPanel editCourse;
    private javax.swing.JLabel editCourseLabel;
    private javax.swing.JLabel enterSearchString;
    private javax.swing.JPanel exitButton;
    private javax.swing.JPanel home;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JPanel mainAddFeesPanel;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JSeparator separator3;
    private javax.swing.JLabel serchRecord;
    private javax.swing.JTable tbl_studentData;
    private javax.swing.JTextField txt_enterSearchString;
    private javax.swing.JPanel viewReport;
    private javax.swing.JLabel viewReportLabel;
    // End of variables declaration//GEN-END:variables
}
