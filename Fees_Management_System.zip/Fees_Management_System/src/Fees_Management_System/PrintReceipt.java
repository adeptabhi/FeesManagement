package Fees_Management_System;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.Year;
import java.util.Date;
import javax.swing.JOptionPane;

public class PrintReceipt extends javax.swing.JFrame {

   
    public PrintReceipt() {
        initComponents();
        getRecord();
    }
    public void getRecord()
    {
        try
        {
            Connection con =DBConnection.getConnection();
            PreparedStatement pst=con.prepareStatement("select * from feesDetails order by id desc limit 1");
            ResultSet rs=pst.executeQuery();
            if(rs.next()==true)
            {    
             txt_receiptNo.setText("UIETFR-"+rs.getString("id"));
             txt_paymentMode.setText(rs.getString("paymentMode"));
             String paymentMode =rs.getString("paymentMode");
             if(paymentMode.equalsIgnoreCase("cash"))
             {
                selectPaymentMode.setVisible(false);
                txt_selectPaymentMode.setVisible(false);
                txt_bankName.setText("_ _ _ _ _");
             }
             if(paymentMode.equalsIgnoreCase("cheque"))
             {
                selectPaymentMode.setText("Cheque No");
                txt_selectPaymentMode.setText(rs.getString("chequeNo"));
                txt_bankName.setText(rs.getString("bankName"));
             }
             if(paymentMode.equalsIgnoreCase("dd"))
             {
                selectPaymentMode.setText("DD No.");
                txt_selectPaymentMode.setText(rs.getString("ddNo"));
                txt_bankName.setText(rs.getString("bankName"));
             }
              if(paymentMode.equalsIgnoreCase("card"))
             {
                selectPaymentMode.setVisible(false);
                txt_selectPaymentMode.setVisible(false);
                txt_bankName.setText(rs.getString("bankName"));
             }
             txt_amount.setText(rs.getString("amount"));
             txt_cgst.setText(rs.getString("cgst"));
             txt_sgst.setText(rs.getString("sgst"));
             txt_total.setText(rs.getString("total"));
             txt_yearFrom.setText(rs.getString("yearFrom"));
             txt_yearTo.setText(rs.getString("yearTo"));
             txt_total.setText(rs.getString("total"));
             txt_gstin.setText(rs.getString("gstin"));
             txt_remarks.setText(rs.getString("remark"));
             txt_totalInWords.setText(rs.getString("totalInWords"));
             txt_courseName.setText(rs.getString("courseName"));
             txt_registrationNo.setText("UIETRS-"+rs.getString("registrationNo"));
             txt_studentName.setText(rs.getString("studentName"));
             txt_date.setText(rs.getString("date"));
            } 
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }    
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainAddFeesPanel = new javax.swing.JPanel();
        leftPanel = new javax.swing.JPanel();
        print = new javax.swing.JPanel();
        printLabel = new javax.swing.JLabel();
        searchRecord = new javax.swing.JPanel();
        searchRecordLabel = new javax.swing.JLabel();
        viewReport = new javax.swing.JPanel();
        viewReportLabel = new javax.swing.JLabel();
        Logout = new javax.swing.JPanel();
        logoutLabel = new javax.swing.JLabel();
        editCourse = new javax.swing.JPanel();
        editCourseLabel = new javax.swing.JLabel();
        courseList = new javax.swing.JPanel();
        courseListLabel = new javax.swing.JLabel();
        home = new javax.swing.JPanel();
        homeLabel = new javax.swing.JLabel();
        RightPanel = new javax.swing.JPanel();
        printPanel = new javax.swing.JPanel();
        separator1 = new javax.swing.JSeparator();
        logo = new javax.swing.JLabel();
        unversityNameLabel = new javax.swing.JLabel();
        unversitySubNameLabel = new javax.swing.JLabel();
        unversityAddressLabel = new javax.swing.JLabel();
        years = new javax.swing.JLabel();
        txt_yearTo = new javax.swing.JLabel();
        paymentMode = new javax.swing.JLabel();
        bankName = new javax.swing.JLabel();
        txt_registrationNo = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        amount = new javax.swing.JLabel();
        selectPaymentMode = new javax.swing.JLabel();
        studentName = new javax.swing.JLabel();
        courseName = new javax.swing.JLabel();
        receiptNo = new javax.swing.JLabel();
        txt_gstin = new javax.swing.JLabel();
        txt_paymentMode = new javax.swing.JLabel();
        txt_selectPaymentMode = new javax.swing.JLabel();
        txt_bankName = new javax.swing.JLabel();
        txt_studentName = new javax.swing.JLabel();
        txt_courseName = new javax.swing.JLabel();
        txt_receiptNo = new javax.swing.JLabel();
        txt_date = new javax.swing.JLabel();
        gstin = new javax.swing.JLabel();
        txt_yearFrom = new javax.swing.JLabel();
        to = new javax.swing.JLabel();
        separator2 = new javax.swing.JSeparator();
        registrationNo = new javax.swing.JLabel();
        sgst = new javax.swing.JLabel();
        head = new javax.swing.JLabel();
        txt_totalInWords = new javax.swing.JLabel();
        cgst = new javax.swing.JLabel();
        courseFee = new javax.swing.JLabel();
        txt_amount = new javax.swing.JLabel();
        txt_cgst = new javax.swing.JLabel();
        separator4 = new javax.swing.JSeparator();
        txt_sgst = new javax.swing.JLabel();
        txt_total = new javax.swing.JLabel();
        totalInWords = new javax.swing.JLabel();
        txt_remarks = new javax.swing.JLabel();
        totalInWords2 = new javax.swing.JLabel();
        receiverSignature = new javax.swing.JLabel();
        separator5 = new javax.swing.JSeparator();
        separator6 = new javax.swing.JSeparator();
        printReceipt = new javax.swing.JLabel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        separator3 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("AddFeesFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainAddFeesPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainAddFeesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        leftPanel.setBackground(new java.awt.Color(0, 102, 102));
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        print.setBackground(new java.awt.Color(0, 102, 102));
        print.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        print.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                printMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                printMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                printMouseExited(evt);
            }
        });

        printLabel.setBackground(new java.awt.Color(0, 102, 102));
        printLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        printLabel.setForeground(new java.awt.Color(255, 255, 255));
        printLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Printer.png"))); // NOI18N
        printLabel.setText("Print");

        javax.swing.GroupLayout printLayout = new javax.swing.GroupLayout(print);
        print.setLayout(printLayout);
        printLayout.setHorizontalGroup(
            printLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(printLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(printLabel)
                .addContainerGap(99, Short.MAX_VALUE))
        );
        printLayout.setVerticalGroup(
            printLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, printLayout.createSequentialGroup()
                .addComponent(printLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(print, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 564, 205, 54));

        searchRecord.setBackground(new java.awt.Color(0, 102, 102));
        searchRecord.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchRecordMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                searchRecordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                searchRecordMouseExited(evt);
            }
        });

        searchRecordLabel.setBackground(new java.awt.Color(0, 102, 102));
        searchRecordLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchRecordLabel.setForeground(new java.awt.Color(255, 255, 255));
        searchRecordLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/SearchRecord.png"))); // NOI18N
        searchRecordLabel.setText("Search Record");

        javax.swing.GroupLayout searchRecordLayout = new javax.swing.GroupLayout(searchRecord);
        searchRecord.setLayout(searchRecordLayout);
        searchRecordLayout.setHorizontalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchRecordLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchRecordLabel)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        searchRecordLayout.setVerticalGroup(
            searchRecordLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, searchRecordLayout.createSequentialGroup()
                .addComponent(searchRecordLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(searchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 144, 205, 54));

        viewReport.setBackground(new java.awt.Color(0, 102, 102));
        viewReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewReportMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewReportMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewReportMouseExited(evt);
            }
        });

        viewReportLabel.setBackground(new java.awt.Color(0, 102, 102));
        viewReportLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        viewReportLabel.setForeground(new java.awt.Color(255, 255, 255));
        viewReportLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/ViewAllRecord.png"))); // NOI18N
        viewReportLabel.setText("View Report");

        javax.swing.GroupLayout viewReportLayout = new javax.swing.GroupLayout(viewReport);
        viewReport.setLayout(viewReportLayout);
        viewReportLayout.setHorizontalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewReportLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(viewReportLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        viewReportLayout.setVerticalGroup(
            viewReportLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewReportLayout.createSequentialGroup()
                .addComponent(viewReportLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(viewReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 396, 205, 54));

        Logout.setBackground(new java.awt.Color(0, 102, 102));
        Logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                LogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                LogoutMouseExited(evt);
            }
        });

        logoutLabel.setBackground(new java.awt.Color(0, 102, 102));
        logoutLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Logout.png"))); // NOI18N
        logoutLabel.setText("Logout");

        javax.swing.GroupLayout LogoutLayout = new javax.swing.GroupLayout(Logout);
        Logout.setLayout(LogoutLayout);
        LogoutLayout.setHorizontalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LogoutLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoutLabel)
                .addContainerGap(80, Short.MAX_VALUE))
        );
        LogoutLayout.setVerticalGroup(
            LogoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LogoutLayout.createSequentialGroup()
                .addComponent(logoutLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(Logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 480, 205, 54));

        editCourse.setBackground(new java.awt.Color(0, 102, 102));
        editCourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editCourseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                editCourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                editCourseMouseExited(evt);
            }
        });

        editCourseLabel.setBackground(new java.awt.Color(0, 102, 102));
        editCourseLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        editCourseLabel.setForeground(new java.awt.Color(255, 255, 255));
        editCourseLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/EditCourse.png"))); // NOI18N
        editCourseLabel.setText("Edit Course");

        javax.swing.GroupLayout editCourseLayout = new javax.swing.GroupLayout(editCourse);
        editCourse.setLayout(editCourseLayout);
        editCourseLayout.setHorizontalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(editCourseLabel)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        editCourseLayout.setVerticalGroup(
            editCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, editCourseLayout.createSequentialGroup()
                .addComponent(editCourseLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(editCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 228, 205, 54));

        courseList.setBackground(new java.awt.Color(0, 102, 102));
        courseList.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        courseList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                courseListMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                courseListMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                courseListMouseExited(evt);
            }
        });

        courseListLabel.setBackground(new java.awt.Color(0, 102, 102));
        courseListLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        courseListLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseListLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/CourseList.png"))); // NOI18N
        courseListLabel.setText("Course List");

        javax.swing.GroupLayout courseListLayout = new javax.swing.GroupLayout(courseList);
        courseList.setLayout(courseListLayout);
        courseListLayout.setHorizontalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(courseListLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(courseListLabel)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        courseListLayout.setVerticalGroup(
            courseListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, courseListLayout.createSequentialGroup()
                .addComponent(courseListLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(courseList, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 312, 205, 54));

        home.setBackground(new java.awt.Color(0, 102, 102));
        home.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                homeMouseExited(evt);
            }
        });

        homeLabel.setBackground(new java.awt.Color(0, 102, 102));
        homeLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        homeLabel.setForeground(new java.awt.Color(255, 255, 255));
        homeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MenuIcons/Home.png"))); // NOI18N
        homeLabel.setText("Home");

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(homeLabel)
                .addContainerGap(89, Short.MAX_VALUE))
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homeLayout.createSequentialGroup()
                .addComponent(homeLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        leftPanel.add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 205, 54));

        mainAddFeesPanel.add(leftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 350, 646));

        RightPanel.setBackground(new java.awt.Color(0, 153, 153));
        RightPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        printPanel.setBackground(new java.awt.Color(255, 255, 255));
        printPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        separator1.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(separator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 540, 210, 10));

        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyIcons/Clg.png"))); // NOI18N
        printPanel.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 120, 110));

        unversityNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 31)); // NOI18N
        unversityNameLabel.setText("University Institute of Engineering and Technology");
        printPanel.add(unversityNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 750, 50));

        unversitySubNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        unversitySubNameLabel.setText("School Of Engineering And Technology");
        printPanel.add(unversitySubNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 45, 520, 40));

        unversityAddressLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        unversityAddressLabel.setText("Kalyanpur, Kanpur, Uttar Pradesh 208012");
        printPanel.add(unversityAddressLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 358, 30));

        years.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        years.setText("The following payment in the college office for the year :");
        printPanel.add(years, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 370, 20));

        txt_yearTo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_yearTo, new org.netbeans.lib.awtextra.AbsoluteConstraints(445, 300, 70, 20));

        paymentMode.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        paymentMode.setText("Payment Mode : ");
        printPanel.add(paymentMode, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 125, 20));

        bankName.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        bankName.setText("Bank Name :");
        printPanel.add(bankName, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 125, 20));

        txt_registrationNo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_registrationNo.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_registrationNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 275, 125, 20));

        date.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        date.setText("Date :");
        printPanel.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 125, 70, 20));

        amount.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        amount.setText("Amount (Rs) :");
        printPanel.add(amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 340, 125, 20));

        selectPaymentMode.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(selectPaymentMode, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 175, 125, 20));

        studentName.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        studentName.setText("Student Name:");
        printPanel.add(studentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 225, 125, 20));

        courseName.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        courseName.setText("Course Name :");
        printPanel.add(courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 125, 20));

        receiptNo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        receiptNo.setText("Receipt No :");
        printPanel.add(receiptNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 125, 125, 20));

        txt_gstin.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_gstin.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_gstin, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 150, 125, 20));

        txt_paymentMode.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_paymentMode.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_paymentMode, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 125, 20));

        txt_selectPaymentMode.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_selectPaymentMode.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_selectPaymentMode, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 175, 125, 20));

        txt_bankName.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_bankName.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_bankName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 125, 20));

        txt_studentName.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_studentName.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_studentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 225, 125, 20));

        txt_courseName.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_courseName.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, 125, 20));

        txt_receiptNo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_receiptNo.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_receiptNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 125, 125, 20));

        txt_date.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt_date.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(txt_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 120, 125, 20));

        gstin.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        gstin.setText("GSTIN :");
        printPanel.add(gstin, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 150, 70, 20));

        txt_yearFrom.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_yearFrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 300, 40, 20));

        to.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        to.setText("To");
        printPanel.add(to, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 300, 20, 20));

        separator2.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(separator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 856, 7));

        registrationNo.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        registrationNo.setText("Registration No :");
        printPanel.add(registrationNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 275, 125, 20));

        sgst.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        sgst.setText("SGST 9%");
        printPanel.add(sgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 422, 125, 20));

        head.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        head.setText("Heads :");
        printPanel.add(head, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, 125, 20));

        txt_totalInWords.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_totalInWords, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 480, 440, 20));

        cgst.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        cgst.setText("CGST 9%");
        printPanel.add(cgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 397, 125, 20));

        courseFee.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        courseFee.setText("Course Fee");
        printPanel.add(courseFee, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 372, 125, 20));

        txt_amount.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 372, 125, 20));

        txt_cgst.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_cgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 397, 125, 20));

        separator4.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(separator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 365, 856, 7));

        txt_sgst.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_sgst, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 422, 125, 20));

        txt_total.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_total, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 455, 125, 20));

        totalInWords.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        totalInWords.setText("Total in Words :");
        printPanel.add(totalInWords, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, 125, 20));

        txt_remarks.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        printPanel.add(txt_remarks, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 530, 440, 20));

        totalInWords2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        totalInWords2.setText("Remark :");
        printPanel.add(totalInWords2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 530, 125, 20));

        receiverSignature.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        receiverSignature.setText("Receiver Signature");
        printPanel.add(receiverSignature, new org.netbeans.lib.awtextra.AbsoluteConstraints(635, 550, 120, 20));

        separator5.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(separator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 447, 175, 10));

        separator6.setForeground(new java.awt.Color(102, 102, 102));
        printPanel.add(separator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 856, 7));

        RightPanel.add(printPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 876, 586));

        printReceipt.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        printReceipt.setForeground(new java.awt.Color(255, 255, 255));
        printReceipt.setText("Print Receipt");
        RightPanel.add(printReceipt, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 220, 40));

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        RightPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(838, 0, 60, -1));

        separator3.setBackground(new java.awt.Color(0, 0, 0));
        separator3.setForeground(new java.awt.Color(0, 0, 0));
        RightPanel.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(306, 40, 280, 5));

        mainAddFeesPanel.add(RightPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 2, 896, 646));

        getContentPane().add(mainAddFeesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void printMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printMouseEntered
        Color clr=new Color(0,153,153);
        print.setBackground(clr);
    }//GEN-LAST:event_printMouseEntered

    private void printMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printMouseExited
         Color clr=new Color(0,102,102);
         print.setBackground(clr);
    }//GEN-LAST:event_printMouseExited

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void printMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printMouseClicked
         PrinterJob job = PrinterJob.getPrinterJob();
         job.setJobName("Print Data");   
         job.setPrintable(new Printable(){
         public int print(Graphics pg,PageFormat pf, int pageNum)
         {
             pf.setOrientation(PageFormat.LANDSCAPE);
                 if(pageNum > 0)
                {
                    return Printable.NO_SUCH_PAGE;
                }
                Graphics2D g2 = (Graphics2D)pg;
                g2.translate(pf.getImageableX(), pf.getImageableY());
                g2.scale(0.47,0.47);
                printPanel.print(g2);
                return Printable.PAGE_EXISTS;
               }
        });
        boolean ok = job.printDialog();
        if(ok)
        {
         try{    
               job.print();
           }
         catch (PrinterException ex)
         {
	     ex.printStackTrace();
         }
        }
    }//GEN-LAST:event_printMouseClicked

    private void searchRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseClicked
        SearchRecord search=new SearchRecord();
        search.show();
        this.dispose();
    }//GEN-LAST:event_searchRecordMouseClicked

    private void searchRecordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseEntered
        Color clr=new Color(0,153,153);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseEntered

    private void searchRecordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchRecordMouseExited
        Color clr=new Color(0,102,102);
        searchRecord.setBackground(clr);
    }//GEN-LAST:event_searchRecordMouseExited

    private void viewReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseClicked
        ViewReport report= new ViewReport();
        report.show();
        this.dispose();
    }//GEN-LAST:event_viewReportMouseClicked

    private void viewReportMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseEntered
        Color clr=new Color(0,153,153);
        viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseEntered

    private void viewReportMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewReportMouseExited
        Color clr=new Color(0,102,102);
        viewReport.setBackground(clr);
    }//GEN-LAST:event_viewReportMouseExited

    private void LogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseClicked
        LoginPage login = new LoginPage();
        login.show();
        this.dispose();
    }//GEN-LAST:event_LogoutMouseClicked

    private void LogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseEntered
        Color clr=new Color(0,153,153);
        Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseEntered

    private void LogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutMouseExited
        Color clr=new Color(0,102,102);
        Logout.setBackground(clr);
    }//GEN-LAST:event_LogoutMouseExited

    private void editCourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseClicked
        EditCourse edit=new EditCourse();
        edit.show();
        this.dispose();
    }//GEN-LAST:event_editCourseMouseClicked

    private void editCourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseEntered
        Color clr=new Color(0,153,153);
        editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseEntered

    private void editCourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editCourseMouseExited
        Color clr=new Color(0,102,102);
        editCourse.setBackground(clr);
    }//GEN-LAST:event_editCourseMouseExited

    private void courseListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseClicked
        ViewCourse view = new ViewCourse();
        view.show();
        this.dispose();
    }//GEN-LAST:event_courseListMouseClicked

    private void courseListMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseEntered
        Color clr=new Color(0,153,153);
        courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseEntered

    private void courseListMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_courseListMouseExited
        Color clr=new Color(0,102,102);
        courseList.setBackground(clr);
    }//GEN-LAST:event_courseListMouseExited

    private void homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseClicked
        HomePage home=new HomePage();
        home.show();
        this.dispose();
    }//GEN-LAST:event_homeMouseClicked

    private void homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseEntered
        Color clr=new Color(0,153,153);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseEntered

    private void homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_homeMouseExited
        Color clr=new Color(0,102,102);
        home.setBackground(clr);
    }//GEN-LAST:event_homeMouseExited

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrintReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrintReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrintReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrintReceipt.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrintReceipt().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JPanel Logout;
    private javax.swing.JPanel RightPanel;
    private javax.swing.JLabel amount;
    private javax.swing.JLabel bankName;
    private javax.swing.JLabel cgst;
    private javax.swing.JLabel courseFee;
    private javax.swing.JPanel courseList;
    private javax.swing.JLabel courseListLabel;
    private javax.swing.JLabel courseName;
    private javax.swing.JLabel date;
    private javax.swing.JPanel editCourse;
    private javax.swing.JLabel editCourseLabel;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel gstin;
    private javax.swing.JLabel head;
    private javax.swing.JPanel home;
    private javax.swing.JLabel homeLabel;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JPanel mainAddFeesPanel;
    private javax.swing.JLabel paymentMode;
    private javax.swing.JPanel print;
    private javax.swing.JLabel printLabel;
    private javax.swing.JPanel printPanel;
    private javax.swing.JLabel printReceipt;
    private javax.swing.JLabel receiptNo;
    private javax.swing.JLabel receiverSignature;
    private javax.swing.JLabel registrationNo;
    private javax.swing.JPanel searchRecord;
    private javax.swing.JLabel searchRecordLabel;
    private javax.swing.JLabel selectPaymentMode;
    private javax.swing.JSeparator separator1;
    private javax.swing.JSeparator separator2;
    private javax.swing.JSeparator separator3;
    private javax.swing.JSeparator separator4;
    private javax.swing.JSeparator separator5;
    private javax.swing.JSeparator separator6;
    private javax.swing.JLabel sgst;
    private javax.swing.JLabel studentName;
    private javax.swing.JLabel to;
    private javax.swing.JLabel totalInWords;
    private javax.swing.JLabel totalInWords2;
    private javax.swing.JLabel txt_amount;
    private javax.swing.JLabel txt_bankName;
    private javax.swing.JLabel txt_cgst;
    private javax.swing.JLabel txt_courseName;
    private javax.swing.JLabel txt_date;
    private javax.swing.JLabel txt_gstin;
    private javax.swing.JLabel txt_paymentMode;
    private javax.swing.JLabel txt_receiptNo;
    private javax.swing.JLabel txt_registrationNo;
    private javax.swing.JLabel txt_remarks;
    private javax.swing.JLabel txt_selectPaymentMode;
    private javax.swing.JLabel txt_sgst;
    private javax.swing.JLabel txt_studentName;
    private javax.swing.JLabel txt_total;
    private javax.swing.JLabel txt_totalInWords;
    private javax.swing.JLabel txt_yearFrom;
    private javax.swing.JLabel txt_yearTo;
    private javax.swing.JLabel unversityAddressLabel;
    private javax.swing.JLabel unversityNameLabel;
    private javax.swing.JLabel unversitySubNameLabel;
    private javax.swing.JPanel viewReport;
    private javax.swing.JLabel viewReportLabel;
    private javax.swing.JLabel years;
    // End of variables declaration//GEN-END:variables
}
