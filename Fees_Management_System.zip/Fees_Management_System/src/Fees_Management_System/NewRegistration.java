package Fees_Management_System;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import javax.swing.JOptionPane;
public class NewRegistration extends javax.swing.JFrame {
    public NewRegistration() {
        initComponents();
        initilization();
        dateTo();
    }
    //Global Variable
    
    String firstName,lastName,contactNo,courseName,coursePrice;
    Date dob;
    public void initilization()
    {
        int registrationNo=0;
         try
            {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst=con.prepareStatement("select max(id) from studentDetails");
              ResultSet rs=pst.executeQuery();
              if(rs.next()==true)
              {
                  registrationNo=rs.getInt("max(id)");
                  registrationNo+=1;
                  txt_registrationNo.setText("UIETRS-"+Integer.toString(registrationNo)); 
              }
            } 
        catch(Exception e)
            {
                e.printStackTrace();
            }
         // to insert course list
          try
            {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst= con.prepareStatement("select courseName from course");
              ResultSet rs=pst.executeQuery();
              while(rs.next())
              {
                  txt_courseName.addItem(rs.getString("courseName"));
              }
            } 
           catch(Exception e)
            {
                e.printStackTrace();
            }
          //for amount
        try
            {
              String coursename=txt_courseName.getSelectedItem().toString();
              Connection con=DBConnection.getConnection();
              PreparedStatement pst= con.prepareStatement("select coursePrice from course where courseName=?");
              pst.setString(1, coursename);
              ResultSet rs=pst.executeQuery();
              while(rs.next())
              {
                  txt_coursePrice.setText(rs.getString("coursePrice"));
                  break;
              } 
            } 
        catch(Exception e)
            {
                e.printStackTrace();
            }
    }        
    public Date dateFrom()
    {
         SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
         Date date = new Date();
         Date nextdate  = Date.from(Instant.now().plusSeconds(86400*365*100)); 
         return nextdate;
    }
    public Date dateTo()
    {
         SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
         Date date = new Date();
         Date nextdate  = Date.from(Instant.now().plusSeconds(-86400*365*5)); 
         txt_dob.setDate(nextdate);
         return nextdate;
    }
    boolean validation()
    {
        boolean flag=false; 
        if(alertFirstName.getText().equals("")&&alertLastName.getText().equals("")&&alertContactNo.getText().equals(""))
        flag=true;       
        return flag;
    }
    public void insertRegistrationDetail()
    {
        firstName=txt_firstName.getText();
        lastName=txt_lastName.getText();
        contactNo=txt_contactNo.getText();
        Date date = new Date();  
        Date dob = txt_dob.getDate();
        long d = dob.getTime();
        courseName=txt_courseName.getSelectedItem().toString();
        coursePrice=txt_coursePrice.getText();
       
        java.sql.Date sqlDob = new java.sql.Date(d);
           try
            {
              Connection con=DBConnection.getConnection();
              String sql="insert into studentdetails(firstName,lastName,courseName,coursePrice,dob,contactNo) values(?,?,?,?,?,?)";
              PreparedStatement pst= con.prepareStatement(sql);
              pst.setString(1,firstName);
              pst.setString(2, lastName);
              pst.setString(3, courseName);
              pst.setString(4, coursePrice);
              pst.setDate(5,sqlDob);
              pst.setString(6, contactNo);
              int updatedRowCount = pst.executeUpdate();
              if(updatedRowCount>0)
              {    
                  JOptionPane.showMessageDialog(this,"New registration success"); 
              } 
              else
                JOptionPane.showMessageDialog(this,"Registration Failure");
            } catch(Exception e)
            {
                e.printStackTrace();
            }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainSignupPanel = new javax.swing.JPanel();
        signupPage = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        signupPageLabel = new javax.swing.JLabel();
        signupPageCreateLabel = new javax.swing.JLabel();
        contactNoLabel = new javax.swing.JLabel();
        firstNameLabel = new javax.swing.JLabel();
        lastNameLabel = new javax.swing.JLabel();
        courseNameLabel = new javax.swing.JLabel();
        coursePriceLabel = new javax.swing.JLabel();
        dobLabel = new javax.swing.JLabel();
        txt_dob = new com.toedter.calendar.JDateChooser();
        alertContactNo = new javax.swing.JTextField();
        alertFirstName = new javax.swing.JTextField();
        alertLastName = new javax.swing.JTextField();
        btn_newRegistration = new javax.swing.JButton();
        txt_firstName = new javax.swing.JTextField();
        txt_lastName = new javax.swing.JTextField();
        txt_contactNo = new javax.swing.JTextField();
        separator3 = new javax.swing.JSeparator();
        rollNoLabel = new javax.swing.JLabel();
        txt_registrationNo = new javax.swing.JTextField();
        txt_courseName = new javax.swing.JComboBox<>();
        btn_back = new javax.swing.JButton();
        txt_coursePrice = new javax.swing.JTextField();
        signupImageLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(2, 2, 2, 2));
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("SignupPageFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainSignupPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainSignupPanel.setForeground(new java.awt.Color(51, 51, 51));
        mainSignupPanel.setMinimumSize(new java.awt.Dimension(1248, 648));
        mainSignupPanel.setPreferredSize(new java.awt.Dimension(1248, 648));
        mainSignupPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        signupPage.setBackground(new java.awt.Color(0, 153, 153));
        signupPage.setToolTipText("");
        signupPage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        signupPage.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(567, 0, 60, -1));

        signupPageLabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        signupPageLabel.setForeground(new java.awt.Color(255, 255, 255));
        signupPageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/signupMain.png"))); // NOI18N
        signupPageLabel.setText("New Registration");
        signupPage.add(signupPageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 340, 50));

        signupPageCreateLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        signupPageCreateLabel.setForeground(new java.awt.Color(255, 255, 255));
        signupPageCreateLabel.setText("Create New Account Here");
        signupPage.add(signupPageCreateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, -1, -1));

        contactNoLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        contactNoLabel.setForeground(new java.awt.Color(255, 255, 255));
        contactNoLabel.setText("Contact No:");
        signupPage.add(contactNoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, 160, 25));

        firstNameLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        firstNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        firstNameLabel.setText("FirstName:");
        signupPage.add(firstNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 160, 25));

        lastNameLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        lastNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        lastNameLabel.setText("Lastame:");
        signupPage.add(lastNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 160, 25));

        courseNameLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        courseNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseNameLabel.setText("Course Name:");
        signupPage.add(courseNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 315, 160, 25));

        coursePriceLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        coursePriceLabel.setForeground(new java.awt.Color(255, 255, 255));
        coursePriceLabel.setText("Course Price:");
        signupPage.add(coursePriceLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 160, 25));

        dobLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        dobLabel.setForeground(new java.awt.Color(255, 255, 255));
        dobLabel.setText("D.O.B:");
        signupPage.add(dobLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 430, 160, 25));

        txt_dob.setBackground(new java.awt.Color(255, 255, 255));
        txt_dob.setMaxSelectableDate(dateTo());
        txt_dob.setMinSelectableDate(dateFrom());
        signupPage.add(txt_dob, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 425, 200, 35));

        alertContactNo.setEditable(false);
        alertContactNo.setBackground(new java.awt.Color(0, 153, 153));
        alertContactNo.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertContactNo.setForeground(new java.awt.Color(102, 51, 0));
        alertContactNo.setText("Enter your Mobile No");
        alertContactNo.setBorder(null);
        alertContactNo.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        alertContactNo.setSelectedTextColor(new java.awt.Color(0, 153, 153));
        signupPage.add(alertContactNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 490, 190, 20));

        alertFirstName.setEditable(false);
        alertFirstName.setBackground(new java.awt.Color(0, 153, 153));
        alertFirstName.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertFirstName.setForeground(new java.awt.Color(102, 51, 0));
        alertFirstName.setText("Enter your first name");
        alertFirstName.setBorder(null);
        alertFirstName.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        signupPage.add(alertFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 200, 190, 20));

        alertLastName.setEditable(false);
        alertLastName.setBackground(new java.awt.Color(0, 153, 153));
        alertLastName.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertLastName.setForeground(new java.awt.Color(102, 51, 0));
        alertLastName.setText("Enter your last name");
        alertLastName.setBorder(null);
        alertLastName.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        signupPage.add(alertLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 260, 190, 20));

        btn_newRegistration.setBackground(new java.awt.Color(0, 102, 102));
        btn_newRegistration.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_newRegistration.setForeground(new java.awt.Color(255, 255, 255));
        btn_newRegistration.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/signup.png"))); // NOI18N
        btn_newRegistration.setText("New Registration");
        btn_newRegistration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_newRegistrationActionPerformed(evt);
            }
        });
        signupPage.add(btn_newRegistration, new org.netbeans.lib.awtextra.AbsoluteConstraints(205, 560, 250, 40));

        txt_firstName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_firstNameKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_firstNameKeyReleased(evt);
            }
        });
        signupPage.add(txt_firstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 195, 200, 35));

        txt_lastName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_lastNameKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_lastNameKeyReleased(evt);
            }
        });
        signupPage.add(txt_lastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 255, 200, 35));

        txt_contactNo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_contactNoKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_contactNoKeyReleased(evt);
            }
        });
        signupPage.add(txt_contactNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 485, 200, 35));

        separator3.setBackground(new java.awt.Color(0, 0, 0));
        separator3.setForeground(new java.awt.Color(0, 0, 0));
        signupPage.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 623, 5));

        rollNoLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        rollNoLabel.setForeground(new java.awt.Color(255, 255, 255));
        rollNoLabel.setText("Registration No:");
        signupPage.add(rollNoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 160, 25));

        txt_registrationNo.setForeground(new java.awt.Color(255, 255, 255));
        txt_registrationNo.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txt_registrationNo.setEnabled(false);
        signupPage.add(txt_registrationNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 135, 200, 35));

        txt_courseName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_courseNameActionPerformed(evt);
            }
        });
        signupPage.add(txt_courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 310, 200, 30));

        btn_back.setBackground(new java.awt.Color(0, 102, 102));
        btn_back.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_back.setForeground(new java.awt.Color(255, 255, 255));
        btn_back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyIcons/back1.png"))); // NOI18N
        btn_back.setText("Back");
        btn_back.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_back.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });
        signupPage.add(btn_back, new org.netbeans.lib.awtextra.AbsoluteConstraints(492, 605, 130, 40));

        txt_coursePrice.setEditable(false);
        txt_coursePrice.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        signupPage.add(txt_coursePrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 365, 200, 35));

        mainSignupPanel.add(signupPage, new org.netbeans.lib.awtextra.AbsoluteConstraints(625, 2, 623, 646));

        signupImageLabel.setBackground(new java.awt.Color(255, 255, 255));
        signupImageLabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        signupImageLabel.setForeground(new java.awt.Color(255, 255, 255));
        signupImageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BgIcons/Student background.png"))); // NOI18N
        mainSignupPanel.add(signupImageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 623, 646));

        getContentPane().add(mainSignupPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));
        mainSignupPanel.getAccessibleContext().setAccessibleName("");
        mainSignupPanel.getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void btn_newRegistrationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_newRegistrationActionPerformed
        if(validation()==true)
        {
              insertRegistrationDetail();
              HomePage home=new HomePage();
              home.show();
              this.dispose();          
        }  
        else
        {
             JOptionPane.showMessageDialog(this,"Please enter all valid details");
        }
    }//GEN-LAST:event_btn_newRegistrationActionPerformed

    private void txt_firstNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_firstNameKeyPressed
         if(txt_firstName.getText().length()==0)
            alertFirstName.setText("Enter your first name");
        else
        if(txt_firstName.getText().matches("^[a-zA-Z]*$")==false)
            alertFirstName.setText("Only Alphabet Allow");
        else
            alertFirstName.setText("");
    }//GEN-LAST:event_txt_firstNameKeyPressed

    private void txt_firstNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_firstNameKeyReleased
         if(txt_firstName.getText().length()==0)
            alertFirstName.setText("Enter your first name");
        else
        if(txt_firstName.getText().matches("^[a-zA-Z]*$")==false)
            alertFirstName.setText("Only Alphabet Allow");
        else
            alertFirstName.setText("");
    }//GEN-LAST:event_txt_firstNameKeyReleased

    private void txt_lastNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_lastNameKeyPressed
        if(txt_lastName.getText().length()==0)
            alertLastName.setText("Enter your last name");
        else
        if(txt_lastName.getText().matches("^[a-zA-Z]*$")==false)
            alertLastName.setText("Only Alphabet Allow");
        else
            alertLastName.setText("");
    }//GEN-LAST:event_txt_lastNameKeyPressed

    private void txt_lastNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_lastNameKeyReleased
         if(txt_lastName.getText().length()==0)
            alertLastName.setText("Enter your last name");
        else
        if(txt_lastName.getText().matches("^[a-zA-Z]*$")==false)
            alertLastName.setText("Only Alphabet Allow");
        else
            alertLastName.setText("");
    }//GEN-LAST:event_txt_lastNameKeyReleased

    private void txt_contactNoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_contactNoKeyPressed
        if(txt_contactNo.getText().length()==0)
            alertContactNo.setText("Enter your contact no");
        else
         if(txt_contactNo.getText().matches("^[0-9]*$")==false) 
             alertContactNo.setText("Only Digit Allow");
        else
           if(txt_contactNo.getText().length()>10||txt_contactNo.getText().length()<10)  
               alertContactNo.setText("Contact no must be 10 digit");
        else
              alertContactNo.setText("");
    }//GEN-LAST:event_txt_contactNoKeyPressed

    private void txt_contactNoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_contactNoKeyReleased
        if(txt_contactNo.getText().length()==0)
            alertContactNo.setText("Enter your contact no");
        else
         if(txt_contactNo.getText().matches("^[0-9]*$")==false) 
             alertContactNo.setText("Only Digit Allow");
        else
           if(txt_contactNo.getText().length()>10||txt_contactNo.getText().length()<10)  
               alertContactNo.setText("Contact no must be 10 digit");
        else
              alertContactNo.setText("");
    }//GEN-LAST:event_txt_contactNoKeyReleased

    private void txt_courseNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_courseNameActionPerformed
        try
        {
            String coursename=txt_courseName.getSelectedItem().toString();
            Connection con=DBConnection.getConnection();
            PreparedStatement pst= con.prepareStatement("select coursePrice from course where courseName=?");
            pst.setString(1, coursename);
            ResultSet rs=pst.executeQuery();
            while(rs.next())
            {
                txt_coursePrice.setText(rs.getString("coursePrice"));
                break;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txt_courseNameActionPerformed

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        HomePage home=new HomePage();
              home.show();
              this.dispose(); 
    }//GEN-LAST:event_btn_backActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewRegistration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JTextField alertContactNo;
    private javax.swing.JTextField alertFirstName;
    private javax.swing.JTextField alertLastName;
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_newRegistration;
    private javax.swing.JLabel contactNoLabel;
    private javax.swing.JLabel courseNameLabel;
    private javax.swing.JLabel coursePriceLabel;
    private javax.swing.JLabel dobLabel;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel firstNameLabel;
    private javax.swing.JLabel lastNameLabel;
    private javax.swing.JPanel mainSignupPanel;
    private javax.swing.JLabel rollNoLabel;
    private javax.swing.JSeparator separator3;
    private javax.swing.JLabel signupImageLabel;
    private javax.swing.JPanel signupPage;
    private javax.swing.JLabel signupPageCreateLabel;
    private javax.swing.JLabel signupPageLabel;
    private javax.swing.JTextField txt_contactNo;
    private javax.swing.JComboBox<String> txt_courseName;
    private javax.swing.JTextField txt_coursePrice;
    private com.toedter.calendar.JDateChooser txt_dob;
    private javax.swing.JTextField txt_firstName;
    private javax.swing.JTextField txt_lastName;
    private javax.swing.JTextField txt_registrationNo;
    // End of variables declaration//GEN-END:variables

}
