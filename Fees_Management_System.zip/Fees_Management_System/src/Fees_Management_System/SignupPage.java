package Fees_Management_System;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import javax.swing.JOptionPane;
public class SignupPage extends javax.swing.JFrame {
    public SignupPage() {
        initComponents();
        insertUserId();
         dateTo();
    }
    //Global Variable
    
    String firstName,lastName,userName,password,confirmPassword,contactNo;
    Date dob;  
    public void insertUserId()
    {
        int userIdNo=0;
         try
            {
              Connection con=DBConnection.getConnection();
              PreparedStatement pst=con.prepareStatement("select max(id) from signupPage");
              ResultSet rs=pst.executeQuery();
              if(rs.next()==true)
              {
                  userIdNo=rs.getInt("max(id)");
                  userIdNo+=1;
                   userName="UIETID-"+Integer.toString(userIdNo);
                  txt_userName.setText(userName);  
              }
            } 
        catch(Exception e)
            {
                e.printStackTrace();
            }
    }        
    public Date dateFrom()
    {
         SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
         Date date = new Date();
         Date nextdate  = Date.from(Instant.now().plusSeconds(86400*365*100)); 
         return nextdate;
    }
    public Date dateTo()
    {
         SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
         Date date = new Date();
         Date nextdate  = Date.from(Instant.now().plusSeconds(-86400*365*5)); 
         txt_dob.setDate(nextdate);
         return nextdate;
    }
    boolean validation()
    {
        boolean flag=false; 
        if(alertFirstName.getText().equals("")&&alertLastName.getText().equals("")&&alertPassword.getText().equals("")&&alertConfirmPassword.getText().equals("")&&alertContactNo.getText().equals(""))
        flag=true;       
        return flag;
    }
    public void insertSignupDetail()
    {
        firstName=txt_firstName.getText();
        lastName=txt_lastName.getText();
        contactNo=txt_contactNo.getText();
        password=txt_password.getText();
        confirmPassword=txt_confirmPassword.getText();
        Date date = new Date();  
        Date dob = txt_dob.getDate();
        long d = dob.getTime();
       
        java.sql.Date sqlDob = new java.sql.Date(d);
           try
            {
              Connection con=DBConnection.getConnection();
              String sql="insert into signupPage(firstName,lastName,password,dob,contactNo) values(?,?,?,?,?)";
              PreparedStatement pst= con.prepareStatement(sql);
              pst.setString(1,firstName);
              pst.setString(2, lastName);
              pst.setString(3, password);
              pst.setDate(4,sqlDob);
              pst.setString(5, contactNo);
              int updatedRowCount = pst.executeUpdate();
              if(updatedRowCount>0)
              {    
                  JOptionPane.showMessageDialog(this,"Your account created Successfully"); 
              } 
              else
                JOptionPane.showMessageDialog(this,"Account creation Failure");
            } catch(Exception e)
            {
                e.printStackTrace();
            }
    }
    public void confirmPassword()
    {
        if(txt_password.getText().length()==0)
            alertConfirmPassword.setText("Enter confirm password");
        else
            if(txt_password.getText().equals(txt_confirmPassword.getText())==false)
            alertConfirmPassword.setText("Confirm password not matched");
        else
            alertConfirmPassword.setText("");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainSignupPanel = new javax.swing.JPanel();
        signupPage = new javax.swing.JPanel();
        exitButton = new javax.swing.JPanel();
        ExitButtonLabel = new javax.swing.JLabel();
        signupPageLabel = new javax.swing.JLabel();
        signupPageCreateLabel = new javax.swing.JLabel();
        contactNoLabel = new javax.swing.JLabel();
        firstNameLabel = new javax.swing.JLabel();
        lastNameLabel = new javax.swing.JLabel();
        passwordLabel = new javax.swing.JLabel();
        confirmPasswordLabel = new javax.swing.JLabel();
        dobLabel = new javax.swing.JLabel();
        txt_dob = new com.toedter.calendar.JDateChooser();
        alertContactNo = new javax.swing.JTextField();
        alertFirstName = new javax.swing.JTextField();
        alertLastName = new javax.swing.JTextField();
        alertPassword = new javax.swing.JTextField();
        alertConfirmPassword = new javax.swing.JTextField();
        btn_login = new javax.swing.JButton();
        btn_signup = new javax.swing.JButton();
        btn_exit = new javax.swing.JButton();
        txt_firstName = new javax.swing.JTextField();
        txt_lastName = new javax.swing.JTextField();
        txt_password = new javax.swing.JPasswordField();
        txt_confirmPassword = new javax.swing.JPasswordField();
        txt_contactNo = new javax.swing.JTextField();
        separator3 = new javax.swing.JSeparator();
        userNameLabel = new javax.swing.JLabel();
        txt_userName = new javax.swing.JTextField();
        signupImageLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(2, 2, 2, 2));
        setMinimumSize(new java.awt.Dimension(1250, 650));
        setName("SignupPageFrame"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainSignupPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 0)));
        mainSignupPanel.setForeground(new java.awt.Color(51, 51, 51));
        mainSignupPanel.setMinimumSize(new java.awt.Dimension(1248, 648));
        mainSignupPanel.setPreferredSize(new java.awt.Dimension(1248, 648));
        mainSignupPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        signupPage.setBackground(new java.awt.Color(0, 153, 153));
        signupPage.setToolTipText("");
        signupPage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitButton.setBackground(new java.awt.Color(0, 153, 153));
        exitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonMouseExited(evt);
            }
        });

        ExitButtonLabel.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        ExitButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        ExitButtonLabel.setText("X");

        javax.swing.GroupLayout exitButtonLayout = new javax.swing.GroupLayout(exitButton);
        exitButton.setLayout(exitButtonLayout);
        exitButtonLayout.setHorizontalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        exitButtonLayout.setVerticalGroup(
            exitButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(exitButtonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitButtonLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        signupPage.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(567, 0, 60, -1));

        signupPageLabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        signupPageLabel.setForeground(new java.awt.Color(255, 255, 255));
        signupPageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/signupMain.png"))); // NOI18N
        signupPageLabel.setText("Signup Page");
        signupPage.add(signupPageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 30, 270, 50));

        signupPageCreateLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        signupPageCreateLabel.setForeground(new java.awt.Color(255, 255, 255));
        signupPageCreateLabel.setText("Create New Account Here");
        signupPage.add(signupPageCreateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 80, -1, -1));

        contactNoLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        contactNoLabel.setForeground(new java.awt.Color(255, 255, 255));
        contactNoLabel.setText("Contact No:");
        signupPage.add(contactNoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, 160, 25));

        firstNameLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        firstNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        firstNameLabel.setText("FirstName:");
        signupPage.add(firstNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 160, 25));

        lastNameLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        lastNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        lastNameLabel.setText("Lastame:");
        signupPage.add(lastNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 160, 25));

        passwordLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        passwordLabel.setForeground(new java.awt.Color(255, 255, 255));
        passwordLabel.setText("Password:");
        signupPage.add(passwordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, 160, 25));

        confirmPasswordLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        confirmPasswordLabel.setForeground(new java.awt.Color(255, 255, 255));
        confirmPasswordLabel.setText("Confirm Password:");
        signupPage.add(confirmPasswordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 160, 25));

        dobLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        dobLabel.setForeground(new java.awt.Color(255, 255, 255));
        dobLabel.setText("D.O.B:");
        signupPage.add(dobLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 430, 160, 25));

        txt_dob.setBackground(new java.awt.Color(255, 255, 255));
        txt_dob.setMaxSelectableDate(dateTo());
        txt_dob.setMinSelectableDate(dateFrom());
        signupPage.add(txt_dob, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 425, 200, 35));

        alertContactNo.setEditable(false);
        alertContactNo.setBackground(new java.awt.Color(0, 153, 153));
        alertContactNo.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertContactNo.setForeground(new java.awt.Color(102, 51, 0));
        alertContactNo.setText("Enter your Mobile No");
        alertContactNo.setBorder(null);
        alertContactNo.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        alertContactNo.setSelectedTextColor(new java.awt.Color(0, 153, 153));
        signupPage.add(alertContactNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 490, 190, 20));

        alertFirstName.setEditable(false);
        alertFirstName.setBackground(new java.awt.Color(0, 153, 153));
        alertFirstName.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertFirstName.setForeground(new java.awt.Color(102, 51, 0));
        alertFirstName.setText("Enter your first name");
        alertFirstName.setBorder(null);
        alertFirstName.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        signupPage.add(alertFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 200, 190, 20));

        alertLastName.setEditable(false);
        alertLastName.setBackground(new java.awt.Color(0, 153, 153));
        alertLastName.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertLastName.setForeground(new java.awt.Color(102, 51, 0));
        alertLastName.setText("Enter your last name");
        alertLastName.setBorder(null);
        alertLastName.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        signupPage.add(alertLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 260, 190, 20));

        alertPassword.setEditable(false);
        alertPassword.setBackground(new java.awt.Color(0, 153, 153));
        alertPassword.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertPassword.setForeground(new java.awt.Color(102, 51, 0));
        alertPassword.setText("Enter your password");
        alertPassword.setBorder(null);
        alertPassword.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        signupPage.add(alertPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 310, 190, 20));

        alertConfirmPassword.setEditable(false);
        alertConfirmPassword.setBackground(new java.awt.Color(0, 153, 153));
        alertConfirmPassword.setFont(new java.awt.Font("Bodoni MT", 0, 14)); // NOI18N
        alertConfirmPassword.setForeground(new java.awt.Color(102, 51, 0));
        alertConfirmPassword.setText("Enter confirm password");
        alertConfirmPassword.setBorder(null);
        alertConfirmPassword.setDisabledTextColor(new java.awt.Color(102, 51, 0));
        signupPage.add(alertConfirmPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 370, 190, 20));

        btn_login.setBackground(new java.awt.Color(0, 102, 102));
        btn_login.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_login.setForeground(new java.awt.Color(255, 255, 255));
        btn_login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/login.png"))); // NOI18N
        btn_login.setText("Login");
        btn_login.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_login.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });
        signupPage.add(btn_login, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 560, 130, 40));

        btn_signup.setBackground(new java.awt.Color(0, 102, 102));
        btn_signup.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_signup.setForeground(new java.awt.Color(255, 255, 255));
        btn_signup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/signup.png"))); // NOI18N
        btn_signup.setText("Signup");
        btn_signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_signupActionPerformed(evt);
            }
        });
        signupPage.add(btn_signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 560, -1, -1));

        btn_exit.setBackground(new java.awt.Color(0, 102, 102));
        btn_exit.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btn_exit.setForeground(new java.awt.Color(255, 255, 255));
        btn_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myIcons/exit.png"))); // NOI18N
        btn_exit.setText("Exit");
        btn_exit.setMaximumSize(new java.awt.Dimension(133, 39));
        btn_exit.setMinimumSize(new java.awt.Dimension(133, 39));
        btn_exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_exitActionPerformed(evt);
            }
        });
        signupPage.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, 130, 40));

        txt_firstName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_firstNameKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_firstNameKeyReleased(evt);
            }
        });
        signupPage.add(txt_firstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 195, 200, 35));

        txt_lastName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_lastNameKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_lastNameKeyReleased(evt);
            }
        });
        signupPage.add(txt_lastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 255, 200, 35));

        txt_password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_passwordKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_passwordKeyReleased(evt);
            }
        });
        signupPage.add(txt_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 305, 200, 35));

        txt_confirmPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_confirmPasswordKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_confirmPasswordKeyReleased(evt);
            }
        });
        signupPage.add(txt_confirmPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 365, 200, 35));

        txt_contactNo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_contactNoKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_contactNoKeyReleased(evt);
            }
        });
        signupPage.add(txt_contactNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 485, 200, 35));

        separator3.setBackground(new java.awt.Color(0, 0, 0));
        separator3.setForeground(new java.awt.Color(0, 0, 0));
        signupPage.add(separator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 623, 5));

        userNameLabel.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        userNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        userNameLabel.setText("UserName:");
        signupPage.add(userNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 160, 25));

        txt_userName.setForeground(new java.awt.Color(255, 255, 255));
        txt_userName.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txt_userName.setEnabled(false);
        signupPage.add(txt_userName, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 135, 200, 35));

        mainSignupPanel.add(signupPage, new org.netbeans.lib.awtextra.AbsoluteConstraints(625, 2, 623, 646));

        signupImageLabel.setBackground(new java.awt.Color(255, 255, 255));
        signupImageLabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 36)); // NOI18N
        signupImageLabel.setForeground(new java.awt.Color(255, 255, 255));
        signupImageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BgIcons/Signup background.png"))); // NOI18N
        mainSignupPanel.add(signupImageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 2, 623, 646));

        getContentPane().add(mainSignupPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 650));
        mainSignupPanel.getAccessibleContext().setAccessibleName("");
        mainSignupPanel.getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonMouseClicked

    private void exitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseEntered
        Color mouseEnterColor = new Color(255,51,51);
        exitButton.setBackground(mouseEnterColor);
    }//GEN-LAST:event_exitButtonMouseEntered

    private void exitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonMouseExited
        Color mouseExitColor = new Color(0,153,153);
        exitButton.setBackground(mouseExitColor);
    }//GEN-LAST:event_exitButtonMouseExited

    private void btn_signupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_signupActionPerformed
        if(validation()==true)
        {
              insertSignupDetail();
              LoginPage login=new LoginPage();
              login.show();
              this.dispose();          
        }  
        else
        {
             JOptionPane.showMessageDialog(this,"Please enter all valid details");
        }
    }//GEN-LAST:event_btn_signupActionPerformed

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
         LoginPage login=new LoginPage();
         login.show();
         this.dispose();
    }//GEN-LAST:event_btn_loginActionPerformed

    private void btn_exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_exitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btn_exitActionPerformed

    private void txt_firstNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_firstNameKeyPressed
         if(txt_firstName.getText().length()==0)
            alertFirstName.setText("Enter your first name");
        else
        if(txt_firstName.getText().matches("^[a-zA-Z]*$")==false)
            alertFirstName.setText("Only Alphabet Allow");
        else
            alertFirstName.setText("");
    }//GEN-LAST:event_txt_firstNameKeyPressed

    private void txt_firstNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_firstNameKeyReleased
         if(txt_firstName.getText().length()==0)
            alertFirstName.setText("Enter your first name");
        else
        if(txt_firstName.getText().matches("^[a-zA-Z]*$")==false)
            alertFirstName.setText("Only Alphabet Allow");
        else
            alertFirstName.setText("");
    }//GEN-LAST:event_txt_firstNameKeyReleased

    private void txt_lastNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_lastNameKeyPressed
        if(txt_lastName.getText().length()==0)
            alertLastName.setText("Enter your last name");
        else
        if(txt_lastName.getText().matches("^[a-zA-Z]*$")==false)
            alertLastName.setText("Only Alphabet Allow");
        else
            alertLastName.setText("");
    }//GEN-LAST:event_txt_lastNameKeyPressed

    private void txt_lastNameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_lastNameKeyReleased
         if(txt_lastName.getText().length()==0)
            alertLastName.setText("Enter your last name");
        else
        if(txt_lastName.getText().matches("^[a-zA-Z]*$")==false)
            alertLastName.setText("Only Alphabet Allow");
        else
            alertLastName.setText("");
    }//GEN-LAST:event_txt_lastNameKeyReleased

    private void txt_passwordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passwordKeyPressed
        if(txt_password.getText().length()==0)
        {   
            alertPassword.setText("Enter your password");
        }    
        else
            if(txt_password.getText().length()<8||txt_password.getText().length()>12)
            alertPassword.setText("Password must be 8 to 12 char");
        else
            alertPassword.setText("");
        confirmPassword();
    }//GEN-LAST:event_txt_passwordKeyPressed

    private void txt_passwordKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passwordKeyReleased
       if(txt_password.getText().length()==0)
            alertPassword.setText("Enter your password");
        else
            if(txt_password.getText().length()<8||txt_password.getText().length()>12)
            alertPassword.setText("Password must be 8 to 12 char");
        else
            alertPassword.setText("");
       confirmPassword();
    }//GEN-LAST:event_txt_passwordKeyReleased

    private void txt_confirmPasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_confirmPasswordKeyPressed
       confirmPassword();
    }//GEN-LAST:event_txt_confirmPasswordKeyPressed

    private void txt_confirmPasswordKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_confirmPasswordKeyReleased
          confirmPassword();
    }//GEN-LAST:event_txt_confirmPasswordKeyReleased

    private void txt_contactNoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_contactNoKeyPressed
        if(txt_contactNo.getText().length()==0)
            alertContactNo.setText("Enter your contact no");
        else
         if(txt_contactNo.getText().matches("^[0-9]*$")==false) 
             alertContactNo.setText("Only Digit Allow");
        else
           if(txt_contactNo.getText().length()>10||txt_contactNo.getText().length()<10)  
               alertContactNo.setText("Contact no must be 10 digit");
        else
           if(txt_contactNo.getText().substring(0,0).equals("0")||txt_contactNo.getText().substring(0,0).equals("1")||txt_contactNo.getText().substring(0,0).equals("2")||txt_contactNo.getText().substring(0,0).equals("3")||txt_contactNo.getText().substring(0,0).equals("4")||txt_contactNo.getText().substring(0,0).equals("5"))
               alertContactNo.setText("enter valid contact no");
        else
              alertContactNo.setText("");
    }//GEN-LAST:event_txt_contactNoKeyPressed

    private void txt_contactNoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_contactNoKeyReleased
        if(txt_contactNo.getText().length()==0)
            alertContactNo.setText("Enter your contact no");
        else
         if(txt_contactNo.getText().matches("^[0-9]*$")==false) 
             alertContactNo.setText("Only Digit Allow");
        else
           if(txt_contactNo.getText().length()>10||txt_contactNo.getText().length()<10)  
               alertContactNo.setText("Contact no must be 10 digit");
        else
              alertContactNo.setText("");
    }//GEN-LAST:event_txt_contactNoKeyReleased
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignupPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignupPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignupPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignupPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignupPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ExitButtonLabel;
    private javax.swing.JTextField alertConfirmPassword;
    private javax.swing.JTextField alertContactNo;
    private javax.swing.JTextField alertFirstName;
    private javax.swing.JTextField alertLastName;
    private javax.swing.JTextField alertPassword;
    private javax.swing.JButton btn_exit;
    private javax.swing.JButton btn_login;
    private javax.swing.JButton btn_signup;
    private javax.swing.JLabel confirmPasswordLabel;
    private javax.swing.JLabel contactNoLabel;
    private javax.swing.JLabel dobLabel;
    private javax.swing.JPanel exitButton;
    private javax.swing.JLabel firstNameLabel;
    private javax.swing.JLabel lastNameLabel;
    private javax.swing.JPanel mainSignupPanel;
    private javax.swing.JLabel passwordLabel;
    private javax.swing.JSeparator separator3;
    private javax.swing.JLabel signupImageLabel;
    private javax.swing.JPanel signupPage;
    private javax.swing.JLabel signupPageCreateLabel;
    private javax.swing.JLabel signupPageLabel;
    private javax.swing.JPasswordField txt_confirmPassword;
    private javax.swing.JTextField txt_contactNo;
    private com.toedter.calendar.JDateChooser txt_dob;
    private javax.swing.JTextField txt_firstName;
    private javax.swing.JTextField txt_lastName;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_userName;
    private javax.swing.JLabel userNameLabel;
    // End of variables declaration//GEN-END:variables

}
